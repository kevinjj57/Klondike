package cs3500.klondike;

import org.junit.Assert;
import org.junit.Test;

import java.util.Arrays;
import java.util.List;

import cs3500.klondike.model.hw02.Card;
import cs3500.klondike.model.hw02.KlondikeModel;
import cs3500.klondike.view.KlondikeTextualView;

/**
 * A test class for the KlondikeTextualView class.
 */
public abstract class TestKTV extends TestKlondikeParts {


  protected KlondikeTextualView ktv(KlondikeModel model, StringBuffer sb) {
    return new KlondikeTextualView(model, sb);
  }

  /**
   * Tests that the drawPile displays correctly in every model.
   */
  @Test
  public void testDrawPile() {
    StringBuffer sb = new StringBuffer();
    KlondikeModel km = makeKM();
    KlondikeTextualView  ktv = ktv(km, sb);
    List<Card> cs = makeDeck(Arrays.asList("A♡", "A♢", "A♣", "A♠"));
    km.startGame(cs, false, 1, 3);
    String act = ktv.toString();
    String exp = "Draw: A♢, A♣, A♠\n";
    boolean ans = act.contains(exp);
    Assert.assertTrue(ans);
  }

  /**
   * Tests that starting foundation displays correctly in each model.
   */
  @Test
  public void testFoundsStart() {
    StringBuffer sb = new StringBuffer();
    KlondikeModel km = makeKM();
    KlondikeTextualView  ktv = ktv(km, sb);
    List<Card> cs = makeDeck(Arrays.asList("A♡", "A♢", "A♣", "A♠"));
    km.startGame(cs, false, 1, 3);
    String act = ktv.toString();
    String exp = "Foundation: <none>, <none>, <none>, <none>\n";
    boolean ans = act.contains(exp);
    Assert.assertTrue(ans);
  }

  /**
   * Tests that starting foundation displays correctly in each model.
   */
  @Test
  public void testPileStart() {
    StringBuffer sb = new StringBuffer();
    KlondikeModel km = makeKM();
    KlondikeTextualView  ktv = ktv(km, sb);
    List<Card> cs = makeDeck(Arrays.asList("A♡", "A♢", "A♣", "A♠"));
    km.startGame(cs, false, 1, 3);
    String act = ktv.toString();
    String exp = "\n A♡";
    boolean ans = act.contains(exp);
    Assert.assertTrue(ans);
  }

  /**
   * Tests that the Draw, Foundation, and Piles format correctly.
   */
  @Test
  public void testFullFormat() {
    StringBuffer sb = new StringBuffer();
    KlondikeModel km = makeKM();
    KlondikeTextualView  ktv = ktv(km, sb);
    List<Card> cs = makeDeck(Arrays.asList("A♡", "A♢", "A♣", "A♠"));
    km.startGame(cs, false, 1, 3);
    String act = ktv.toString();
    String exp = "Draw: A♢, A♣, A♠\nFoundation: <none>, <none>, <none>, <none>\n A♡";
    Assert.assertEquals(exp, act);
  }

  /**
   * Tests that empty piles display as X's.
   */
  @Test
  public void testMtPiles() {
    StringBuffer sb = new StringBuffer();
    KlondikeModel km = makeKM();
    KlondikeTextualView  ktv = ktv(km, sb);
    List<Card> cs = makeDeck(Arrays.asList("A♡", "A♢", "A♣", "A♠"));
    km.startGame(cs, false, 2, 3);
    km.moveToFoundation(0, 0);
    String act = ktv.toString();
    String exp = "  X";
    boolean ans = act.contains(exp);
    Assert.assertTrue(ans);
  }

  /**
   * Tests that foundation piles update properly.
   */
  @Test
  public void testUpdatedFoundPiles() {
    StringBuffer sb = new StringBuffer();
    KlondikeModel km = makeKM();
    KlondikeTextualView  ktv = ktv(km, sb);
    List<Card> cs = makeDeck(Arrays.asList("A♡", "A♢", "A♣", "A♠"));
    km.startGame(cs, false, 1, 3);
    km.moveToFoundation(0, 0);
    String act = ktv.toString();
    String exp = "Foundation: A♡, <none>, <none>, <none>";
    boolean ans = act.contains(exp);
    Assert.assertTrue(ans);
  }

  /**
   * Tests that the DrawPile may appear empty.
   */
  @Test
  public void testMtDraw() {
    StringBuffer sb = new StringBuffer();
    KlondikeModel km = makeKM();
    KlondikeTextualView  ktv = ktv(km, sb);
    List<Card> cs = makeDeck(Arrays.asList("A♡", "A♢", "A♣", "A♠"));
    km.startGame(cs, false, 2, 3);
    km.moveDrawToFoundation(0);
    String act = ktv.toString();
    String exp = "Draw: \n";
    boolean ans = act.contains(exp);
    Assert.assertTrue(ans);
  }

  /**
   * Tests the number of lines displayed.
   */
  @Test
  public void testCountLines() {
    StringBuffer sb = new StringBuffer();
    KlondikeModel km = makeKM();
    KlondikeTextualView  ktv = ktv(km, sb);
    km.startGame(km.getDeck(), true, 7, 3);
    String act = ktv.toString();
    int numLines = act.lines().toArray().length;
    Assert.assertEquals(9, numLines);
  }

  /**
   * Tests that discarding rotates through the deck for all models.
   */
  @Test
  public void testDiscRotate() {
    StringBuffer sb = new StringBuffer();
    KlondikeModel km = makeKM();
    KlondikeTextualView  ktv = ktv(km, sb);
    List<Card> cs = makeDeck(Arrays.asList("A♡", "A♢", "A♣", "A♠"));
    km.startGame(cs, false, 1, 1);
    String act1 = ktv.toString();
    boolean ans1 = act1.contains("Draw: A♢\n");
    km.discardDraw();
    String act2 = ktv.toString();
    boolean ans2 = act2.contains("Draw: A♣\n");
    km.discardDraw();
    String act3 = ktv.toString();
    boolean ans3 = act3.contains("Draw: A♠\n");
    boolean ans = ans1 && ans2 && ans3;
    Assert.assertTrue(ans);
  }

  /**
   * Tests that the CascadePiles Display as expected for all Klondike Models.
   */
  @Test
  public abstract void testCascade();
}
