package cs3500.klondike;

import org.junit.Assert;
import org.junit.Test;

import java.util.Arrays;
import java.util.List;

import cs3500.klondike.model.hw02.Card;
import cs3500.klondike.model.hw02.KlondikeModel;
import cs3500.klondike.model.hw04.KlondikeCreator;
import cs3500.klondike.view.KlondikeTextualView;

/**
 * Tests for the use of KlondikeTextualView on a LimitedModel.
 */
public class TestKTVLimited extends TestKTV {

  @Override
  protected KlondikeModel makeKM() {
    return KlondikeCreator.create(KlondikeCreator.GameType.LIMITED);
  }

  /**
   * Tests that the CascadePiles Display as expected for all the Limited Klondike Model.
   */
  @Override
  public void testCascade() {
    StringBuffer sb = new StringBuffer();
    KlondikeModel km = makeKM();
    KlondikeTextualView ktv = ktv(km, sb);
    List<Card> cs = makeDeck(Arrays.asList(
            "A♡", "A♢", "A♣", "A♠",
            "A♡", "A♢", "A♣", "A♠",
            "A♡", "A♢", "A♣", "A♠"));
    km.startGame(cs, false, 4, 1);
    String act = ktv.toString();
    String exp =
            "Draw: A♣\n" +
                    "Foundation: <none>, <none>, <none>, <none>, <none>, <none>, <none>, <none>, " +
                    "<none>, <none>, <none>, <none>\n" +
                    " A♡  ?  ?  ?\n" +
                    "    A♡  ?  ?\n" +
                    "       A♠  ?\n" +
                    "          A♢";
    Assert.assertEquals(exp, act);
  }

  /**
   * Tests that discarded cards actually get removed from the view.
   */
  @Test
  public void testDiscardDifference() {
    StringBuffer sb = new StringBuffer();
    KlondikeModel km = makeKM();
    KlondikeTextualView  ktv = ktv(km, sb);
    List<Card> cs = makeDeck(Arrays.asList("A♡", "A♢", "A♣", "A♠"));
    km.startGame(cs, false, 1, 3);
    km.discardDraw();
    km.discardDraw();
    km.discardDraw();
    String act = ktv.toString();
    String exp = "Draw: ";
    boolean ans = act.contains(exp);
    Assert.assertTrue(ans);
  }
}
