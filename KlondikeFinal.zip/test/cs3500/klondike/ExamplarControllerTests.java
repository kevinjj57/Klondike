package cs3500.klondike;

import cs3500.klondike.controller.KlondikeTextualController;
import cs3500.klondike.model.hw02.BasicKlondike;
import cs3500.klondike.model.hw02.Card;

import cs3500.klondike.view.KlondikeTextualView;

import org.junit.Assert;
import org.junit.Test;

import java.io.LineNumberReader;
import java.io.Reader;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Tests for the KlonkdikeTextualController class.
 */
public class ExamplarControllerTests {


  private BasicKlondike bk = new BasicKlondike();

  private void reset() {
    bk = new BasicKlondike();
  }


  private List<Card> makeDeck(List<String> strings) {
    reset();
    List<Card> ans = new ArrayList<Card>();
    for (String s : strings) {
      for (Card c : bk.getDeck()) {
        if (c.toString().equals(s)) {
          ans.add(c);
        }
      }
    }
    return ans;
  }

  /**
   * Tests the full output for quitting the game when using a lowercase q.
   */
  @Test
  public void testQuitGameLower() {
    // use the various Assert static methods to build your examples here.
    reset();
    Reader in = new StringReader("q");
    StringBuilder out = new StringBuilder();
    List<Card> cs = makeDeck(Arrays.asList("A♡", "A♢", "A♣", "A♠"));
    new KlondikeTextualController(in, out).playGame(bk, cs, false, 2, 1);
    boolean ans0 = out.toString().contains(
            "Game quit!\n" +
                    "State of game when quit:\n" +
                    "Draw: A♠\n" +
                    "Foundation: <none>, <none>, <none>, <none>\n" +
                    " A♡  ?\n" +
                    "    A♣\n" +
                    "Score: 0\n"
    );
    Assert.assertTrue(ans0);
  }

  /**
   * Tests the full output for quitting the game when using an uppercase q.
   */
  @Test
  public void testQuitGameUpper() {
    // use the various Assert static methods to build your examples here.
    reset();
    Reader in = new StringReader("q");
    StringBuilder out = new StringBuilder();
    List<Card> cs = makeDeck(Arrays.asList("A♡", "A♢", "A♣", "A♠"));
    new KlondikeTextualController(in, out).playGame(bk, cs, false, 2, 1);
    boolean ans0 = out.toString().contains(
            "Game quit!\n" +
                    "State of game when quit:\n" +
                    "Draw: A♠\n" +
                    "Foundation: <none>, <none>, <none>, <none>\n" +
                    " A♡  ?\n" +
                    "    A♣\n" +
                    "Score: 0\n"
    );
    Assert.assertTrue(ans0);
  }

  /**
   * Tests that spaces have no effect on the controller's ability to process inputs.
   */
  @Test
  public void testSpaces() {
    reset();
    Reader in = new StringReader("     q      ");
    StringBuilder out = new StringBuilder();
    KlondikeTextualController ktc = new KlondikeTextualController(in, out);
    ktc.playGame(bk, makeDeck(
            Arrays.asList("A♡", "A♢", "A♣", "A♠")), false, 2, 1);
    boolean ans = out.toString().contains("Game quit!\n");
    Assert.assertTrue(ans);
  }

  /**
   * Tests that the second line of the quit message appears properly when q is pressed.
   */
  @Test
  public void testQuitSecondLine() {
    reset();
    Reader in = new StringReader("q");
    StringBuilder out = new StringBuilder();
    List<Card> cs = makeDeck(Arrays.asList("A♡", "A♢", "A♣", "A♠"));
    new KlondikeTextualController(in, out).playGame(bk, cs, false, 2, 1);
    boolean ans0 = out.toString().contains("State of game when quit:\n");
    Assert.assertTrue(ans0);
  }

  /**
   * Tests that the board displays correctly on quit game.
   */
  @Test
  public void testQuitBoard() {
    reset();
    Reader in = new StringReader("q");
    StringBuilder out = new StringBuilder();
    List<Card> cs = makeDeck(Arrays.asList("A♡", "A♢", "A♣", "A♠"));
    new KlondikeTextualController(in, out).playGame(bk, cs, false, 2, 1);
    boolean ans0 = out.toString().contains(
            "Draw: A♠\n" +
                    "Foundation: <none>, <none>, <none>, <none>\n" +
                    " A♡  ?\n" +
                    "    A♣\n");
    Assert.assertTrue(ans0);
  }

  /**
   * Tests whether the board displays correctly when the game is quit.
   */
  @Test
  public void testMiddleLines() {
    reset();
    Reader in = new StringReader("q");
    StringBuilder out = new StringBuilder();
    List<Card> cs = makeDeck(Arrays.asList("A♡", "A♢", "A♣", "A♠"));
    new KlondikeTextualController(in, out).
            playGame(bk, cs, false, 2, 1);
    boolean ans0 = out.toString().contains(
            "Draw: A♠\n" +
                    "Foundation: <none>, <none>, <none>, <none>\n" +
                    " A♡  ?\n" +
                    "    A♣\n"
    );
    Assert.assertTrue(ans0);
  }

  /**
   * Tests that attempting to move the same pile States Invalid Move.
   */
  @Test
  public void testBadMPPSamePile() {
    reset();
    Reader in = new StringReader("mpp 1 1 1 q");
    StringBuilder out = new StringBuilder();
    List<Card> cs = makeDeck(Arrays.asList("A♡", "A♢", "A♣", "A♠"));
    new KlondikeTextualController(in, out).playGame(bk, cs, false, 2, 1);
    boolean ans = out.toString().contains("Invalid move. Play again.");
    Assert.assertTrue(ans);
  }

  /**
   * Tests whether typing pile numbers without a move states that it is an invalid move.
   */
  @Test
  public void testRandoNumbers() {
    reset();
    Reader in = new StringReader("1 2 q");
    StringBuilder out = new StringBuilder();
    List<Card> cs = makeDeck(Arrays.asList("A♡", "A♢", "A♣", "A♠"));
    new KlondikeTextualController(in, out).playGame(bk, cs, false, 2, 1);
    boolean ans = out.toString().contains("Invalid move. Play again.");
    Assert.assertTrue(ans);
  }

  /**
   * Tests that once you begin a move, other moves typed
   * don't run until the first move has been complete.
   */
  @Test
  public void testCallWithinCall() {
    reset();
    Reader in = new StringReader("mpf dd 1 1 q");
    StringBuilder out = new StringBuilder();
    List<Card> cs = makeDeck(Arrays.asList("A♡", "A♢", "A♣", "A♠"));
    new KlondikeTextualController(in, out).playGame(bk, cs, false, 2, 1);
    boolean ans = out.toString().contains("Foundation: A♡, <none>, <none>, <none>\n");
    Assert.assertTrue(ans);
  }

  /**
   * Tests that the move draw method actually moves the card.
   */
  @Test
  public void testDrawCardMovement() {
    reset();
    Reader in = new StringReader("md 1 q");
    StringBuilder out = new StringBuilder();
    List<Card> cs = makeDeck(Arrays.asList(
            "2♡", "A♢", "A♣", "A♠",
            "A♡", "2♢", "2♣", "2♠"));
    new KlondikeTextualController(in, out).playGame(bk, cs, false, 2, 1);
    String exp = " 2♡  ?\n A♠ A♣";
    boolean ans = out.toString().contains(exp);
    Assert.assertTrue(ans);
  }

  /**
   * Tests that the move pile method actually moves a single card.
   */
  @Test
  public void testCascadeCardMovement() {
    reset();
    Reader in = new StringReader("mpp 2 1 1 q");
    StringBuilder out = new StringBuilder();
    List<Card> cs = makeDeck(Arrays.asList(
            "2♡", "A♢", "A♣", "A♠",
            "A♡", "2♢", "2♣", "2♠"));
    new KlondikeTextualController(in, out).playGame(bk, cs, false, 2, 1);
    String exp = " 2♡ A♢\n A♣";
    boolean ans = out.toString().contains(exp);
    Assert.assertTrue(ans);
  }

  /**
   * Tests that the move pile method actually moves a single card.
   */
  @Test
  public void testCascadeCardsMovement() {
    reset();
    Reader in = new StringReader("mpp 3 1 2 mpp 2 2 1 q");
    StringBuilder out = new StringBuilder();
    List<Card> cs = makeDeck(Arrays.asList(
            "3♡", "2♢", "A♣", "2♠",
            "A♡", "A♢", "2♣", "A♠",
            "2♡", "3♢", "3♣", "3♠"));
    new KlondikeTextualController(in, out).playGame(bk, cs, false, 3, 1);
    String exp = " 3♡ 2♢  ?\n 2♠    A♡\n A♢";
    boolean ans = out.toString().contains(exp);
    Assert.assertTrue(ans);
  }

  /**
   * Tests that having incorrect inputs within a method call does not state an illegal move,
   * and instead keeps looking for next valid input.
   */
  @Test
  public void testErrors() {
    reset();
    Reader in = new StringReader("mpf 1 b b b b 1 q");
    StringBuilder out = new StringBuilder();
    List<Card> cs = makeDeck(Arrays.asList(
            "A♡", "A♢", "A♣", "A♠"));
    new KlondikeTextualController(in, out).playGame(bk, cs, false, 2, 1);
    String exp = "Invalid move. Play again.";
    boolean ans = out.toString().contains(exp);
    Assert.assertFalse(ans);
  }

  /**
   * Tests that a null model inputted to playGame throws an Illegal Argument Exception.
   */
  @Test
  public void testPG() {
    KlondikeTextualController ktc =
            new KlondikeTextualController(
                    new StringReader("q"),
                    new StringBuilder());
    Assert.assertThrows("Null Model",
            IllegalArgumentException.class, () -> ktc.playGame(
                    null, new ArrayList<>(), false, 0, 0));
  }

  /**
   * Tests that an empty string inputted into the reader throws an Illegal State exception.
   */
  @Test
  public void testMtReader() {
    reset();
    Reader in = new StringReader("");
    StringBuilder out = new StringBuilder();
    List<Card> cs = makeDeck(Arrays.asList("A♡", "A♢", "A♣", "A♠"));
    KlondikeTextualController ktc = new KlondikeTextualController(in, out);
    Assert.assertThrows("Bad reader",
            IllegalArgumentException.class, () -> ktc.playGame(
                    bk, cs, false, 2, 1));
  }

  /**
   * Tests that an appendable with characters already in place throws an Illegal State Exception.
   */
  @Test
  public void testBadApp() {
    reset();
    Reader in = new StringReader("q");
    StringBuilder out = new StringBuilder("         ");
    List<Card> cs = makeDeck(Arrays.asList(
            "2♡", "A♢", "A♣", "A♠",
            "A♡", "2♢", "2♣", "2♠"));
    new KlondikeTextualController(in, out).playGame(bk, cs, false, 2, 1);
    KlondikeTextualController ktc = new KlondikeTextualController(in, out);
    Assert.assertThrows("Bad Appendable",
            IllegalStateException.class, () -> ktc.playGame(
                    bk, cs, false, 2, 1));
  }

  /**
   * Tests that a move pile integer that has a source pile greater than the number
   * of piles states an Invalid Move.
   */
  @Test
  public void testBadMPPSrcHigh() {
    reset();
    Reader in = new StringReader("mpp 10 1 1 q");
    StringBuilder out = new StringBuilder();
    List<Card> cs = makeDeck(Arrays.asList("A♡", "A♢", "A♣", "A♠"));
    new KlondikeTextualController(in, out).playGame(bk, cs, false, 2, 1);
    boolean ans = out.toString().contains("Invalid move. Play again.");
    Assert.assertTrue(ans);
  }

  /**
   * Tests that a move pile integer that has a destination pile greater than the number
   * of piles states an Invalid Move.
   */
  @Test
  public void testBadMPPDestHigh() {
    reset();
    Reader in = new StringReader("mpp 1 10 1 q");
    StringBuilder out = new StringBuilder();
    List<Card> cs = makeDeck(Arrays.asList("A♡", "A♢", "A♣", "A♠"));
    new KlondikeTextualController(in, out).playGame(bk, cs, false, 2, 1);
    boolean ans = out.toString().contains("Invalid move. Play again.");
    Assert.assertTrue(ans);
  }

  /**
   * Tests that a move pile integer that has a number of cards greater than the number
   * of cards in the pile states an Invalid Move.
   */
  @Test
  public void testBadMPPNumCardsHigh() {
    reset();
    Reader in = new StringReader("mpp 1 1 5 q");
    StringBuilder out = new StringBuilder();
    List<Card> cs = makeDeck(Arrays.asList("A♡", "A♢", "A♣", "A♠"));
    new KlondikeTextualController(in, out).playGame(bk, cs, false, 2, 1);
    boolean ans = out.toString().contains("Invalid move. Play again.");
    Assert.assertTrue(ans);
  }

  /**
   * Tests that an invalid source pile integer that is too low does not state
   * an invalid move, and instead continues to look for another value.
   */
  @Test
  public void testBadMPPSrcLow() {
    reset();
    Reader in = new StringReader("mpp -1 2 1 1 q");
    StringBuilder out = new StringBuilder();
    List<Card> cs = makeDeck(Arrays.asList(
            "2♡", "A♢", "A♣", "A♠",
            "A♡", "2♢", "2♣", "2♠"));
    new KlondikeTextualController(in, out).playGame(bk, cs, false, 2, 1);
    boolean ans = out.toString().contains(" 2♡ A♢\n A♣");
    Assert.assertTrue(ans);
  }


  @Test
  public void testBadMPPDestLow() {
    reset();
    Reader in = new StringReader("mpp 2 1 -1 1 q");
    StringBuilder out = new StringBuilder();
    List<Card> cs = makeDeck(Arrays.asList(
            "2♡", "A♢", "A♣", "A♠",
            "A♡", "2♢", "2♣", "2♠"));
    new KlondikeTextualController(in, out).playGame(bk, cs, false, 2, 1);
    boolean ans = out.toString().contains("Invalid move. Play again. Bad move pile values.");
    Assert.assertTrue(ans);
  }

  /**
   * Tests that an invalid number of cards integer that is zero does not state
   * an invalid move, and instead continues to look for another value.
   */
  @Test
  public void testBadMPPNumCardsZero() {
    reset();
    Reader in = new StringReader("mpp 2 0 1 1 q");
    StringBuilder out = new StringBuilder();
    List<Card> cs = makeDeck(Arrays.asList(
            "2♡", "A♢", "A♣", "A♠",
            "A♡", "2♢", "2♣", "2♠"));
    new KlondikeTextualController(in, out).playGame(bk, cs, false, 2, 1);
    boolean ans = out.toString().contains(" 2♡ A♢\n A♣");
    Assert.assertTrue(ans);
  }

  /**
   * Tests that an invalid number of cards integer that is negative does not state
   * an invalid move, and instead continues to look for another value.
   */
  @Test
  public void testBadMPPNumCardsNeg() {
    reset();
    Reader in = new StringReader("mpp 2 -1 1 1 q");
    StringBuilder out = new StringBuilder();
    List<Card> cs = makeDeck(Arrays.asList(
            "2♡", "A♢", "A♣", "A♠",
            "A♡", "2♢", "2♣", "2♠"));
    new KlondikeTextualController(in, out).playGame(bk, cs, false, 2, 1);
    boolean ans = out.toString().contains(" 2♡ A♢\n A♣");
    Assert.assertTrue(ans);
  }

  /**
   * Tests that imputting a null klondike into playGame throws an Illegal Argument Exception.
   */
  @Test
  public void testNullKlondike() {
    reset();
    Reader in = new StringReader("q");
    StringBuilder out = new StringBuilder();
    KlondikeTextualController ktc = new KlondikeTextualController(in, out);
    Assert.assertThrows("Model can't be null",
            IllegalArgumentException.class, () -> ktc.playGame(
                    null, bk.getDeck(), false, 2, 1));
  }

  /**
   * Tests that trying to play a game that has already been started
   * throws an Illegal State Exception.
   */
  @Test
  public void testGameAlreadyStarted() {
    reset();
    bk.startGame(bk.getDeck(), true, 1, 1);
    Reader in = new StringReader("q");
    StringBuilder out = new StringBuilder();
    KlondikeTextualController ktc = new KlondikeTextualController(in, out);
    Assert.assertThrows("Game Already Started",
            IllegalStateException.class, () -> ktc.playGame(
                    bk, bk.getDeck(), false, 2, 1));
  }

  /**
   * Tests that the score updates properly after moving a card to foundation piles.
   */
  @Test
  public void testUpdateScore() {
    reset();
    Reader in = new StringReader("mpf 1 1 q");
    StringBuilder out = new StringBuilder();
    List<Card> cs = makeDeck(Arrays.asList("A♡", "A♢", "A♣", "A♠"));
    new KlondikeTextualController(in, out).playGame(bk, cs, false, 2, 1);
    KlondikeTextualView ktv = new KlondikeTextualView(bk);
    boolean ans = out.toString().contains("Score: 1");
    Assert.assertTrue(ans);
  }

  /**
   * Tests that a bad reader throws an IllegalStateException.
   * Currently, does not work against my own code.
   */
  @Test
  public void testBadReader() {
    reset();
    Reader in = new LineNumberReader(new StringReader("A\nb\nc\nd"));
    StringBuilder out = new StringBuilder();
    List<Card> cs = makeDeck(Arrays.asList("A♡", "A♢", "A♣", "A♠"));
    KlondikeTextualController ktc = new KlondikeTextualController(in, out);
    Assert.assertThrows("Bad reader",
            IllegalStateException.class, () -> ktc.playGame(
                    bk, cs, false, 2, 1));
  }

  /**
   * Tests that entering a q mid-method call ends the game.
   */
  @Test
  public void testQuitMidInput() {
    reset();
    Reader in = new StringReader("mpp 0 q");
    StringBuilder out = new StringBuilder();
    List<Card> cs = makeDeck(Arrays.asList("A♡", "A♢", "A♣", "A♠"));
    new KlondikeTextualController(in, out).playGame(bk, cs, false, 2, 1);
    boolean ans = out.toString().contains("Game quit!\n");
    Assert.assertTrue(ans);
  }

  /**
   * Tests that after moving all cards out of the draw pile, it displays correctly.
   */
  @Test
  public void testGoodMtDraw() {
    reset();
    Reader in = new StringReader("mdf 1 q");
    StringBuilder out = new StringBuilder();
    List<Card> cs = makeDeck(Arrays.asList("A♡", "A♢", "A♣", "A♠"));
    new KlondikeTextualController(in, out).playGame(bk, cs, false, 2, 1);
    boolean ans = out.toString().contains("Draw: \n");
    Assert.assertTrue(ans);
  }

  /**
   * Tests that moving a card to foundation works correctly.
   */
  @Test
  public void testGoodMPF() {
    reset();
    Reader in = new StringReader("mpf 1 1 q");
    StringBuilder out = new StringBuilder();
    List<Card> cs = makeDeck(Arrays.asList("A♡", "A♢", "A♣", "A♠"));
    new KlondikeTextualController(in, out).playGame(bk, cs, false, 2, 1);
    boolean ans = out.toString().contains("Foundation: A♡, <none>, <none>, <none>\n");
    Assert.assertTrue(ans);
  }

  /**
   * Tests that the discard draw input properly flips through the cards.
   */
  @Test
  public void testDD() {
    reset();
    Reader in = new StringReader("dd dd dd dd q");
    StringBuilder out = new StringBuilder();
    List<Card> cs = makeDeck(Arrays.asList("A♡", "A♢", "A♣", "A♠"));
    new KlondikeTextualController(in, out).playGame(bk, cs, false, 1, 1);
    boolean ans0 = out.toString().contains("Draw: A♢\n");
    boolean ans1 = out.toString().contains("Draw: A♣\n");
    boolean ans2 = out.toString().contains("Draw: A♠\n");
    boolean ans = ans0 && ans1 && ans2;
    Assert.assertTrue(ans);
  }

  /**
   * Tests that attempting to discard an empty draw pile states an invalid move.
   */
  @Test
  public void testFlipMtPile() {
    reset();
    Reader in = new StringReader("mdf 1 dd q");
    StringBuilder out = new StringBuilder();
    List<Card> cs = makeDeck(Arrays.asList("A♡", "A♢", "A♣", "A♠"));
    new KlondikeTextualController(in, out).playGame(bk, cs, false, 2, 1);
    boolean ans = out.toString().contains("Invalid move. Play again.");
    Assert.assertTrue(ans);
  }

  /**
   * Tests that the win method displays properly.
   */
  @Test
  public void testWin() {
    reset();
    Reader in = new StringReader("mdf 1 mpf 1 2 mpf 2 3 mpf 2 4");
    StringBuilder out = new StringBuilder();
    List<Card> cs = makeDeck(Arrays.asList("A♡", "A♢", "A♣", "A♠"));
    new KlondikeTextualController(in, out).playGame(bk, cs, false, 2, 1);
    boolean ans = out.toString().contains("You win!");
    Assert.assertTrue(ans);
  }

  /**
   * Tests whether an over game returns the correct message.
   */
  @Test
  public void testGameOver() {
    reset();
    Reader in = new StringReader("mdf 1 q");
    StringBuilder out = new StringBuilder();
    List<Card> cs = makeDeck(Arrays.asList(
            "2♡", "A♢", "A♣", "4♠",
            "3♡", "2♢", "2♣", "2♠",
            "A♡", "3♢", "3♣", "3♠",
            "4♡", "4♣", "4♢", "A♠"));
    new KlondikeTextualController(in, out).playGame(bk, cs, false, 5, 1);
    boolean ans = out.toString().contains("Game over. Score: 1");
    Assert.assertTrue(ans);
  }

  /**
   * Tests that a null reader throws an Illegal Argument Exception.
   */
  @Test
  public void testNullReader() {
    reset();
    Reader in = null;
    StringBuilder out = new StringBuilder();
    List<Card> cs = makeDeck(Arrays.asList("A♡", "A♢", "A♣", "A♠"));
    Assert.assertThrows("Controller can't interact",
            IllegalArgumentException.class, () -> new KlondikeTextualController(in, out).playGame(
                    bk, cs, false, 2, 1));
  }

  /**
   * Tests that the first line of quitting displays correctly.
   */
  @Test
  public void testQuitFirstLine() {
    reset();
    Reader in = new StringReader("q");
    StringBuilder out = new StringBuilder();
    List<Card> cs = makeDeck(Arrays.asList("A♡", "A♢", "A♣", "A♠"));
    new KlondikeTextualController(in, out).playGame(bk, cs, false, 2, 1);
    boolean ans0 = out.toString().contains("Game quit!\n");
    Assert.assertTrue(ans0);
  }

  /**
   * Tests that the last line of quitting displays correctly.
   */
  @Test
  public void testQuitLastLine() {
    reset();
    Reader in = new StringReader("q");
    StringBuilder out = new StringBuilder();
    List<Card> cs = makeDeck(Arrays.asList("A♡", "A♢", "A♣", "A♠"));
    new KlondikeTextualController(in, out).playGame(bk, cs, false, 2, 1);
    boolean ans0 = out.toString().contains("Score: 0\n");
    Assert.assertTrue(ans0);
  }

  /**
   * Tests that no spaces counts as a move.
   */
  @Test
  public void testNoSpaces() {
    reset();
    Reader in = new StringReader("md1 q");
    StringBuilder out = new StringBuilder();
    List<Card> cs = makeDeck(Arrays.asList("A♡", "A♢", "A♣", "A♠"));
    new KlondikeTextualController(in, out).playGame(bk, cs, false, 2, 1);
    boolean ans = out.toString().contains("Invalid move. Play again.");
    Assert.assertTrue(ans);
  }
}


