package cs3500.klondike;

import org.junit.Assert;
import org.junit.Test;

import java.util.Arrays;
import java.util.List;

import cs3500.klondike.model.hw02.Card;
import cs3500.klondike.model.hw02.KlondikeModel;
import cs3500.klondike.model.hw02.MyCard;

/**
 * A class full of methods to help test all models.
 */
public abstract class TestModel extends TestKlondikeParts {


  /**
   * Checks to make sure the deck is 52 cards long and includes each one of the traditional cards.
   */
  @Test
  public void checkGetDeck() {
    KlondikeModel km = makeKM();
    List<String> cs = Arrays.asList(
            "A♡", "A♢", "A♣", "A♠",
            "2♡", "2♢", "2♣", "2♠",
            "3♡", "3♢", "3♣", "3♠",
            "4♡", "4♢", "4♣", "4♠",
            "5♡", "5♢", "5♣", "5♠",
            "6♡", "6♢", "6♣", "6♠",
            "7♡", "7♢", "7♣", "7♠",
            "8♡", "8♢", "8♣", "8♠",
            "9♡", "9♢", "9♣", "9♠",
            "10♡", "10♢", "10♣", "10♠",
            "J♡", "J♢", "J♣", "J♠",
            "Q♡", "Q♢", "Q♣", "Q♠",
            "K♡", "K♢", "K♣", "K♠");

    Assert.assertEquals(52, km.getDeck().size());
    Assert.assertTrue(
            cs.stream().allMatch(s -> (
                    km.getDeck().stream().map(c -> c.toString()).anyMatch(cts -> s.equals(cts)))));
  }

  @Test
  public void checkShuffleDoesntBreakDeck() {
    KlondikeModel km = makeKM();
    km.startGame(km.getDeck(), true, 2, 1);
    Assert.assertEquals(52, km.getDeck().size());
  }

  @Test
  public void checkGetDeckImmutable() {
    KlondikeModel km = makeKM();
    List<Card> cs = km.getDeck();
    cs.remove(0);
    Assert.assertNotEquals(km.getDeck(), cs);
  }

  /**
   * Checks that a legal deck without equal sized runs of every suit does not throw exception.
   * Has bogus test at bottom just to make sure it gets there.
   */
  @Test
  public void checkLegalDeck() {
    KlondikeModel km = makeKM();
    List<Card> cs = makeDeck(Arrays.asList(
            "A♡", "A♢", "A♠", "A♠",
            "2♡", "2♢", "2♠", "2♠",
            "3♡", "3♢", "3♠", "3♠",
            "4♡", "4♢", "4♠", "4♠",
            "5♡", "5♢", "5♠", "5♠",
            "6♡", "6♢", "6♠", "6♠",
            "7♡", "7♢", "7♠", "7♠",
            "8♡", "8♢", "8♠", "8♠",
            "9♡", "9♢", "9♠", "9♠",
            "10♡", "10♢", "10♠", "10♠",
            "J♡", "J♢", "J♠", "J♠",
            "Q♡", "Q♢", "Q♠", "Q♠",
            "K♡", "K♢", "K♠", "K♠"));
    km.startGame(cs, false, 1, 1);
    Assert.assertTrue(km.isCardVisible(0, 0));
  }


  /**
   * Checks to make sure an IAE is thrown when the number of piles is zero for startgame.
   */
  @Test
  public void checkStartGameZeroNumPiles() {
    KlondikeModel km = makeKM();
    Assert.assertThrows("Num Piles Zero",
            IllegalArgumentException.class, () -> km.startGame(
                    km.getDeck(), false, 0, 1));
  }

  /**
   * Checks to make sure an IAE is thrown when the number of piles is negative for startgame.
   */
  @Test
  public void checkStartGameNegNumPiles() {
    KlondikeModel km = makeKM();
    Assert.assertThrows("Num Piles Negative",
            IllegalArgumentException.class, () -> km.startGame(
                    km.getDeck(), false, -1, 1));
  }

  /**
   * Checks to make sure an IAE is thrown when the number of piles is too high for startgame.
   */
  @Test
  public void checkStartGameHighNumPiles() {
    KlondikeModel km = makeKM();
    Assert.assertThrows("Num Piles High",
            IllegalArgumentException.class, () -> km.startGame(
                    km.getDeck(), false, 10, 1));
  }

  /**
   * Checks to make sure an IAE is thrown when the number of piles is zero for startgame.
   */
  @Test
  public void checkStartGameZeroNumDraw() {
    KlondikeModel km = makeKM();
    Assert.assertThrows("Zero Num Draw",
            IllegalArgumentException.class, () -> km.startGame(
                    km.getDeck(), false, 9, 0));
  }

  /**
   * Checks to make sure an IAE is thrown when the number of piles is negative for startgame.
   */
  @Test
  public void checkStartGameNegNumDraw() {
    KlondikeModel km = makeKM();
    Assert.assertThrows("Negative Num Draw",
            IllegalArgumentException.class, () -> km.startGame(
                    km.getDeck(), false, 9, -1));
  }

  /**
   * Checks to make sure shuffle works properly. Test will fail in one in every 51! times.
   */
  @Test
  public void checkShuffle() {
    KlondikeModel km = makeKM();
    List<Card> cs = makeDeck(
            Arrays.asList(
                    "A♡", "A♢", "A♣", "A♠",
                    "2♡", "2♢", "2♣", "2♠",
                    "3♡", "3♢", "3♣", "3♠",
                    "4♡", "4♢", "4♣", "4♠",
                    "5♡", "5♢", "5♣", "5♠",
                    "6♡", "6♢", "6♣", "6♠",
                    "7♡", "7♢", "7♣", "7♠",
                    "8♡", "8♢", "8♣", "8♠",
                    "9♡", "9♢", "9♣", "9♠",
                    "10♡", "10♢", "10♣", "10♠",
                    "J♡", "J♢", "J♣", "J♠",
                    "Q♡", "Q♢", "Q♣", "Q♠",
                    "K♡", "K♢", "K♣", "K♠"));
    //The ace of hearts would be the one card placed down in an unshuffled game,
    //and the rest would be in the drawpile
    km.startGame(cs, true, 1, 51);
    List<Card> shuffled = km.getDrawCards();
    //Removes the ace of hearts as would be expected in an unshuffled game.
    cs.remove(0);
    Assert.assertNotSame(cs, shuffled);
  }

  /**
   * Checks that a given null deck throws proper IAE.
   */
  @Test
  public void checkNullDeck() {
    KlondikeModel km = makeKM();
    Assert.assertThrows("Null Deck",
            IllegalArgumentException.class, () -> km.startGame(
                    null, false, 1, 1));
  }

  /**
   * Checks that attempting to start a game that has already been started throws ISE.
   */
  @Test
  public void checkGameAlreadyStarted() {
    KlondikeModel km = makeKM();
    km.startGame(km.getDeck(), true, 1, 1);
    Assert.assertThrows("Game already started",
            IllegalStateException.class, () -> km.startGame(
                    km.getDeck(), true, 1, 1));
  }

  /**
   * Checks that enough piles have been made in accordance with start game.
   */
  @Test
  public void checkEnoughPilesMade() {
    KlondikeModel km = makeKM();
    km.startGame(km.getDeck(), true, 9, 1);
    Assert.assertEquals(9, km.getNumPiles());
  }

  /**
   * Checks that enough draw cards have been made in accordance with start game.
   */
  @Test
  public void checkEnoughDraw() {
    KlondikeModel km = makeKM();
    km.startGame(km.getDeck(), true, 9, 1);
    Assert.assertEquals(1, km.getNumDraw());
  }

  /**
   * Checks that the propper number of rows have been created with start game.
   * The number of rows to start a game should always be equal to the number of piles.
   */
  @Test
  public void checkGoodRows() {
    KlondikeModel km = makeKM();
    km.startGame(km.getDeck(), true, 9, 1);
    Assert.assertEquals(9, km.getNumRows());
  }

  /**
   * Checks that a given deck with null cards throws proper IAE.
   */
  @Test
  public void checkNullCards() {
    KlondikeModel km = makeKM();
    List<Card> loc = Arrays.asList(new MyCard(MyCard.CardVal.SEVEN, MyCard.Suit.SPADES), null);
    Assert.assertThrows("Null card",
            IllegalArgumentException.class, () -> km.startGame(loc, false, 1, 1));
  }


  /**
   * Checks that an invalid deck, where runs skip numbers, throws IAE.
   */
  @Test
  public void checkBadDeckRuns() {
    KlondikeModel km = makeKM();
    List<Card> cs = makeDeck(Arrays.asList("A♡", "A♢", "A♣", "A♠", "3♡", "3♢", "3♣", "3♠"));
    Assert.assertThrows("Bad runs",
            IllegalArgumentException.class, () -> km.startGame(
                    cs, true, 1, 1));
  }

  /**
   * Checks that movePile throws ISE if the game hasn't been started.
   */
  @Test
  public void checkMovePileGameNotStarted() {
    KlondikeModel km = makeKM();
    Assert.assertThrows("Game hasn't started",
            IllegalStateException.class, () -> km.movePile(
                    0, 1, 1));
  }

  /**
   * Checks that the game will not let you attempt a movePile if the game is over.
   */
  @Test
  public void checkMPGameOver() {
    KlondikeModel km = makeKM();
    List<Card> cs = makeDeck(Arrays.asList(
            "2♡", "A♢", "A♣", "4♠",
            "3♡", "2♢", "2♣", "2♠",
            "A♡", "3♢", "3♣", "3♠",
            "4♡", "4♣", "4♢", "A♠"));
    km.startGame(cs, false, 5, 1);
    km.moveDrawToFoundation(0);
    Assert.assertThrows("Game is over",
            IllegalStateException.class, () -> km.movePile(0, 1, 1));
  }

  /**
   * Checks that movePile throws IAE when srcPile is too high.
   */
  @Test
  public void checkMovePileHighSrc() {
    KlondikeModel km = makeKM();
    km.startGame(km.getDeck(), false, 9, 1);
    Assert.assertThrows("src too high",
            IllegalArgumentException.class, () -> km.movePile(9, 1, 1));
  }

  /**
   * Checks that movePile throws IAE when srcPile is negative.
   */
  @Test
  public void checkMovePileNegSrc() {
    KlondikeModel km = makeKM();
    km.startGame(km.getDeck(), false, 9, 1);
    Assert.assertThrows("src too low",
            IllegalArgumentException.class, () -> km.movePile(-1, 1, 1));
  }

  /**
   * Checks that movePile throws IAE when destPile is too high.
   */
  @Test
  public void checkMovePileHighDest() {
    KlondikeModel km = makeKM();
    km.startGame(km.getDeck(), false, 9, 1);
    Assert.assertThrows("dest too high",
            IllegalArgumentException.class, () -> km.movePile(1, 1, 9));
  }

  /**
   * Checks that movePile throws IAE when destPile is negative.
   */
  @Test
  public void checkMovePileNegDest() {
    KlondikeModel km = makeKM();
    km.startGame(km.getDeck(), false, 9, 1);
    Assert.assertThrows("dest too high",
            IllegalArgumentException.class, () -> km.movePile(1, 1, -1));
  }

  /**
   * Checks that movePile throws IAE when destPile is the same as srcPile.
   */
  @Test
  public void checkMovePileSameNum() {
    KlondikeModel km = makeKM();
    km.startGame(km.getDeck(), false, 9, 1);
    Assert.assertThrows("same pile num",
            IllegalArgumentException.class, () -> km.movePile(1, 1, 1));
  }

  /**
   * Checks that movePile throws IAE when there is not enough cards to move.
   */
  @Test
  public void checkMovePile() {
    KlondikeModel km = makeKM();
    km.startGame(km.getDeck(), false, 9, 1);
    Assert.assertThrows("not enough cards",
            IllegalArgumentException.class, () -> km.movePile(0, 2, 1));
  }

  /**
   * Checks that moveDraw throws ISE if the game hasn't been started.
   */
  @Test
  public void checkMoveDrawGameNotStarted() {
    KlondikeModel km = makeKM();
    Assert.assertThrows("Game has not been started",
            IllegalStateException.class, () -> km.moveDraw(0));
  }

  /**
   * Checks that the game will not let you attempt a moveDraw if the game is over.
   */
  @Test
  public void checkMDGameOver() {
    KlondikeModel km = makeKM();
    List<Card> cs = makeDeck(Arrays.asList(
            "2♡", "A♢", "A♣", "4♠",
            "3♡", "2♢", "2♣", "2♠",
            "A♡", "3♢", "3♣", "3♠",
            "4♡", "4♣", "4♢", "A♠"));
    km.startGame(cs, false, 5, 1);
    km.moveDrawToFoundation(0);
    Assert.assertThrows("Game is over",
            IllegalStateException.class, () -> km.moveDraw(0));
  }

  /**
   * Checks that moveDraw throws IAE if the dest pile is too high.
   */
  @Test
  public void cccheckMoveDrawHighDest() {
    KlondikeModel km = makeKM();
    km.startGame(km.getDeck(), false, 9, 1);
    Assert.assertThrows("dest high",
            IllegalArgumentException.class, () -> km.moveDraw(9));
  }

  /**
   * Checks that moveDraw throws IAE if the dest pile is too low.
   */
  @Test
  public void checkMovePileLowDest() {
    KlondikeModel km = makeKM();
    km.startGame(km.getDeck(), false, 9, 1);
    Assert.assertThrows("dest low",
            IllegalArgumentException.class, () -> km.moveDraw(-1));
  }

  /**
   * Checks that moveDraw throws ISE if the move to cascade is illegal.
   */
  @Test
  public void checkIllegalMoveDrawDownThrows() {
    KlondikeModel km = makeKM();
    List<Card> cs = makeDeck(Arrays.asList("A♡", "A♢", "A♣", "A♠"));
    km.startGame(km.getDeck(), false, 2, 1);
    Assert.assertThrows("Illegal move down",
            IllegalStateException.class, () -> km.moveDraw(0));
  }

  /**
   * Checks that moveDraw throws ISE if the move to cascade is illegal.
   */
  @Test
  public void checkMtMoveDrawThrows() {
    KlondikeModel km = makeKM();
    List<Card> cs = makeDeck(Arrays.asList("A♡", "A♢", "A♣", "A♠"));
    km.startGame(cs, false, 2, 1);
    km.moveDrawToFoundation(0);
    Assert.assertThrows("Draw empty",
            IllegalStateException.class, () -> km.moveDraw(0));
  }

  /**
   * Checks that moveToFoundation throws ISE if the game hasn't been started.
   */
  @Test
  public void checkMTFGameNotStarted() {
    KlondikeModel km = makeKM();
    Assert.assertThrows("Game not started",
            IllegalStateException.class, () -> km.moveToFoundation(0, 0));
  }

  /**
   * Checks that the game will not let you attempt a moveToFoundation if the game is over.
   */
  @Test
  public void checkMTFGameOver() {
    KlondikeModel km = makeKM();
    List<Card> cs = makeDeck(Arrays.asList(
            "2♡", "A♢", "A♣", "4♠",
            "3♡", "2♢", "2♣", "2♠",
            "A♡", "3♢", "3♣", "3♠",
            "4♡", "4♣", "4♢", "A♠"));
    km.startGame(cs, false, 5, 1);
    km.moveDrawToFoundation(0);
    Assert.assertThrows("Game is over",
            IllegalStateException.class, () -> km.moveToFoundation(0, 0));
  }

  /**
   * Checks that a the source pile in moveToFoundation is zero based
   * and throws an IAE if given an integer equal to the number of piles.
   */
  @Test
  public void checkMTFHighSrc() {
    KlondikeModel km = makeKM();
    km.startGame(km.getDeck(), false, 1, 1);
    Assert.assertThrows("Src high",
            IllegalArgumentException.class, () -> km.moveToFoundation(1, 0));
  }

  /**
   * Checks that attempting to move a card from cascade to foundation from a negative source
   * pile throws an IAE.
   */
  @Test
  public void checkMTFLowSrc() {
    KlondikeModel km = makeKM();
    km.startGame(km.getDeck(), false, 1, 1);
    Assert.assertThrows("Src low",
            IllegalArgumentException.class, () -> km.moveToFoundation(-1, 0));
  }

  /**
   * Checks that attempting to move a card from cascade to foundation from a high foundation
   * pile throws an IAE.
   */
  @Test
  public void checkMTFHighFound() {
    KlondikeModel km = makeKM();
    km.startGame(km.getDeck(), false, 1, 1);
    Assert.assertThrows("Found high",
            IllegalArgumentException.class, () -> km.moveToFoundation(0, 4));
  }

  /**
   * Checks that attempting to move a card from cascade to foundation from a negative foundation
   * pile throws an IAE.
   */
  @Test
  public void checkMTFLowFound() {
    KlondikeModel km = makeKM();
    km.startGame(km.getDeck(), false, 1, 1);
    Assert.assertThrows("Found low",
            IllegalArgumentException.class, () -> km.moveToFoundation(0, -1));
  }

  /**
   * Checks that attempting to move a card from draw to foundation when it has not started throws
   * an IAE.
   */
  @Test
  public void checkMDTFGameNotStarted() {
    KlondikeModel km = makeKM();
    Assert.assertThrows("Game not started",
            IllegalStateException.class, () -> km.moveDrawToFoundation(0));
  }

  /**
   * Checks that the game will not let you attempt a moveDrawToFoundation if the game is over.
   */
  @Test
  public void checkMDTFGameOver() {
    KlondikeModel km = makeKM();
    List<Card> cs = makeDeck(Arrays.asList(
            "2♡", "A♢", "A♣", "4♠",
            "3♡", "2♢", "2♣", "2♠",
            "A♡", "3♢", "3♣", "3♠",
            "4♡", "4♣", "4♢", "A♠"));
    km.startGame(cs, false, 5, 1);
    km.moveDrawToFoundation(0);
    Assert.assertThrows("Game is over",
            IllegalStateException.class, () -> km.moveDrawToFoundation(0));
  }

  /**
   * Checks that attempted to move a card from the draw pile to the foundation pile with a negative
   * pileNum throws an IAE.
   */
  @Test
  public void checkMDTFLowFound() {
    KlondikeModel km = makeKM();
    km.startGame(km.getDeck(), false, 9, 1);
    Assert.assertThrows("High found",
            IllegalArgumentException.class, () -> km.moveDrawToFoundation(-1));
  }

  /**
   * Checks that foundation pile numbers are zero-based, and that an IAE is thrown if you give a
   * number greater than or equal to the number of piles.
   */
  @Test
  public void checkMDTFHighFound() {
    KlondikeModel km = makeKM();
    km.startGame(km.getDeck(), false, 9, 1);
    Assert.assertThrows("High found",
            IllegalArgumentException.class, () -> km.moveDrawToFoundation(4));
  }

  /**
   * Checks that attempting to move a card from draw to foundation throws an ISE if the
   * suit is the same, but the values are equal.
   */
  @Test
  public void checkMDTFSameNumAndSuit() {
    KlondikeModel km = makeKM();
    List<Card> cs = makeDeck(Arrays.asList("A♡", "A♢", "A♣", "A♡", "A♠", "A♢", "A♣", "A♠"));
    km.startGame(cs, false, 2, 1);
    km.moveToFoundation(0, 0);
    Assert.assertThrows("Card must be one greater",
            IllegalStateException.class, () -> km.moveDrawToFoundation(0));
  }

  /**
   * Checks that attempting to move a card from draw to foundation throws an ISE if the
   * value is correct, but the suits are not the same.
   */
  @Test
  public void checkMDTFGoodNumBadSuit() {
    KlondikeModel km = makeKM();
    List<Card> cs = makeDeck(Arrays.asList("A♡", "A♢", "A♣", "2♠", "2♡", "2♢", "2♣", "A♠"));
    km.startGame(cs, false, 2, 1);
    km.moveToFoundation(0, 0);
    Assert.assertThrows("Card must be same suit",
            IllegalStateException.class, () -> km.moveDrawToFoundation(0));
  }

  /**
   * Checks that attempting to move a card from the draw pile to a foundation throws an ISE if
   * the draw pile is empty.
   */
  @Test
  public void checkMDTFMtDraw() {
    KlondikeModel km = makeKM();
    List<Card> cs = makeDeck(Arrays.asList("A♡", "A♢", "A♣", "A♠"));
    km.startGame(cs, false, 2, 1);
    km.moveDrawToFoundation(0);
    Assert.assertThrows("Draw Pile Empty",
            IllegalStateException.class, () -> km.moveDrawToFoundation(1));
  }

  /**
   * Checks that attempting to discard a card when the game has not been started throws an ISE.
   */
  @Test
  public void checkDDGameNotStarted() {
    KlondikeModel km = makeKM();
    Assert.assertThrows("Game not started",
            IllegalStateException.class, () -> km.discardDraw());
  }

  /**
   * Checks that the game will not let you attempt a discardDraw if the game is over.
   */
  @Test
  public void checkDDGameOver() {
    KlondikeModel km = makeKM();
    List<Card> cs = makeDeck(Arrays.asList(
            "2♡", "A♢", "A♣", "4♠",
            "3♡", "2♢", "2♣", "2♠",
            "A♡", "3♢", "3♣", "3♠",
            "4♡", "4♣", "4♢", "A♠"));
    km.startGame(cs, false, 5, 1);
    km.moveDrawToFoundation(0);
    Assert.assertThrows("Game is over",
            IllegalStateException.class, () -> km.discardDraw());
  }

  /**
   * Checks that discardDraw throws an ISE if thr drawPile is empty.
   */
  @Test
  public void checkDDMtDraw() {
    KlondikeModel km = makeKM();
    List<Card> cs = makeDeck(Arrays.asList("A♡", "A♢", "A♣", "A♠"));
    km.startGame(cs, false, 2, 1);
    km.moveDrawToFoundation(0);
    Assert.assertThrows("Draw Pile Empty",
            IllegalStateException.class, () -> km.discardDraw());
  }

  /**
   * CHecks that attempting to get the number of rows in this game throws an ISE if the game
   * has not been started.
   */
  @Test
  public void checkGetNumRowsGameNotStarted() {
    KlondikeModel km = makeKM();
    Assert.assertThrows("Game not started",
            IllegalStateException.class, () -> km.getNumRows());
  }

  /**
   * Checks that when a game begins it has the correct answer to getNUmRows.
   */
  @Test
  public void checkGetNumRowsBeginsCorrect() {
    KlondikeModel km = makeKM();
    List<Card> cs = makeDeck(Arrays.asList("A♡", "A♢", "A♣", "A♠"));
    km.startGame(cs, false, 2, 1);
    Assert.assertEquals(2, km.getNumRows());
  }

  /**
   * Checks that getNum rows will decrease if you move a card from the cascade pile to
   * the foundation piles.
   */
  @Test
  public void checkGetNumRowsAdjusts() {
    KlondikeModel km = makeKM();
    List<Card> cs = makeDeck(Arrays.asList("A♡", "A♢", "A♣", "A♠"));
    km.startGame(cs, false, 2, 1);
    km.moveToFoundation(1, 0);
    Assert.assertEquals(1, km.getNumRows());
  }

  /**
   * Checks that getNumPiles throws an ISE if the game has not been started.
   */
  @Test
  public void checkGetNumPilesGameNotStarted() {
    KlondikeModel km = makeKM();
    Assert.assertThrows("Game not started",
            IllegalStateException.class, () -> km.getNumPiles());
  }

  /**
   * Check that getNumPiles returns the appropriate value after beginning a game.
   */
  @Test
  public void checkNumPiles() {
    KlondikeModel km = makeKM();
    km.startGame(km.getDeck(), false, 9, 1);
    Assert.assertEquals(9, km.getNumPiles());
  }

  /**
   * Checks that getNumPiles still counts empty piles as piles.
   */
  @Test
  public void checkGetNumPilesNoChangeMtPiles() {
    KlondikeModel km = makeKM();
    List<Card> cs = makeDeck(Arrays.asList("A♡", "A♢", "A♣", "A♠"));
    km.startGame(cs, false, 2, 1);
    km.moveToFoundation(0, 0);
    Assert.assertEquals(2, km.getNumPiles());
  }

  /**
   * Checks that getNumDraw throws an ISE if the game has not been started.
   */
  @Test
  public void checkGetNumDrawGameNotStarted() {
    KlondikeModel km = makeKM();
    Assert.assertThrows("Game not started",
            IllegalStateException.class, () -> km.getNumDraw());
  }

  /**
   * Checks that getNumDraw returns the correct answer.
   */
  @Test
  public void checkNumDraw() {
    KlondikeModel km = makeKM();
    km.startGame(km.getDeck(), false, 9, 1);
    Assert.assertEquals(1, km.getNumDraw());
  }

  /**
   * Checks that getNumDraw does not change after a discard
   * if there is still more cards in the drawPile.
   */
  @Test
  public void checkGetNumDrawAfterDisc() {
    KlondikeModel km = makeKM();
    List<Card> cs = makeDeck(Arrays.asList("A♡", "A♢", "A♣", "A♠"));
    km.startGame(cs, false, 2, 1);
    km.moveDrawToFoundation(0);
    Assert.assertEquals(1, km.getNumDraw());
  }

  /**
   * Check that getScore throws an ISE if the game has not been started.
   */
  @Test
  public void checkGetScoreGameNotStarted() {
    KlondikeModel km = makeKM();
    Assert.assertThrows("Game not started",
            IllegalStateException.class, () -> km.getScore());
  }

  /**
   * Checks that getScore increases after moving cards to the foundationPiles.
   */
  @Test
  public void checkGetScoreUpdates() {
    KlondikeModel km = makeKM();
    List<Card> cs = makeDeck(Arrays.asList("A♡", "A♢", "A♣", "A♠"));
    km.startGame(cs, false, 2, 1);
    Assert.assertEquals(0, km.getScore());
    km.moveDrawToFoundation(0);
    Assert.assertEquals(1, km.getScore());
  }

  /**
   * Checks that getScore returns the sum of all values, not just the maximum.
   */
  @Test
  public void checkGetScoreUpdatesAcrossMultiplePiles() {
    KlondikeModel km = makeKM();
    List<Card> cs = makeDeck(Arrays.asList("A♡", "A♢", "A♣", "A♠"));
    km.startGame(cs, false, 2, 1);
    Assert.assertEquals(0, km.getScore());
    km.moveDrawToFoundation(0);
    Assert.assertEquals(1, km.getScore());
    km.moveToFoundation(0, 2);
    Assert.assertEquals(2, km.getScore());
  }

  /**
   * Checks that getPileHeigh throws an ISE if the game has not been started.
   */
  @Test
  public void checkGetPileHeightNotStarted() {
    KlondikeModel km = makeKM();
    Assert.assertThrows("Game not started",
            IllegalStateException.class, () -> km.getPileHeight(0));
  }

  /**
   * Checks that getPileHeight changes if you move a card out of the pile.
   */
  @Test
  public void checkGetPileHeightUpdates() {
    KlondikeModel km = makeKM();
    List<Card> cs = makeDeck(Arrays.asList("A♡", "A♢", "A♣", "A♠"));
    km.startGame(cs, false, 2, 1);
    Assert.assertEquals(1, km.getPileHeight(0));
    km.moveToFoundation(0, 0);
    Assert.assertEquals(0, km.getPileHeight(0));
  }

  /**
   * Checks that getPileHeigh throws an IAE if the pileNum is negative.
   */
  @Test
  public void checkGetPileHeightThrowsLow() {
    KlondikeModel km = makeKM();
    List<Card> cs = makeDeck(Arrays.asList("A♡", "A♢", "A♣", "A♠"));
    km.startGame(cs, false, 2, 1);
    Assert.assertThrows("Pile Num Low",
            IllegalArgumentException.class, () -> km.getPileHeight(-1));
  }

  /**
   * Checks that getPile height is zero-based and throws an IAE if the pileNum is
   * greater than or equal to the number of piles in this game.
   */
  @Test
  public void checkGetPileHighZeroBased() {
    KlondikeModel km = makeKM();
    List<Card> cs = makeDeck(Arrays.asList("A♡", "A♢", "A♣", "A♠"));
    km.startGame(cs, false, 2, 1);
    Assert.assertThrows("Pile Num High",
            IllegalArgumentException.class, () -> km.getPileHeight(2));
  }

  /**
   * Checks that isCard Visable throws an ISE if the game has not been started.
   */
  @Test
  public void checkIsCardVisNotStarted() {
    KlondikeModel km = makeKM();
    Assert.assertThrows("Game not started",
            IllegalStateException.class, () -> km.isCardVisible(0, 0));
  }

  /**
   * Checks that isCardVisible is zero-based and throws an IAE if the cardNum is
   * greater than or equal to the pileHeight.
   */
  @Test
  public void checkIsCardVisCardZeroBased() {
    KlondikeModel km = makeKM();
    List<Card> cs = makeDeck(Arrays.asList("A♡", "A♢", "A♣", "A♠"));
    km.startGame(cs, false, 2, 1);
    Assert.assertThrows("Card Num High",
            IllegalArgumentException.class, () -> km.getCardAt(0, 1));
  }

  /**
   * Checks that isCardVisible is zero-based and throws an IAE if the pileNum is
   * greater than or equal to the number of piles.
   */
  @Test
  public void checkIsCardVisPileZeroBased() {
    KlondikeModel km = makeKM();
    List<Card> cs = makeDeck(Arrays.asList("A♡", "A♢", "A♣", "A♠"));
    km.startGame(cs, false, 2, 1);
    Assert.assertThrows("Pile Num High",
            IllegalArgumentException.class, () -> km.getCardAt(2, 1));
  }

  /**
   * Checks that isCardVisible throws an IAE if the card is negative.
   */
  @Test
  public void checkIsCardVisCardLow() {
    KlondikeModel km = makeKM();
    List<Card> cs = makeDeck(Arrays.asList("A♡", "A♢", "A♣", "A♠"));
    km.startGame(cs, false, 2, 1);
    Assert.assertThrows("Card Num Low",
            IllegalArgumentException.class, () -> km.getCardAt(0, -1));
  }

  /**
   * Checks that isCardVisible throws an IAE if the pileNum is negative.
   */
  @Test
  public void checkIsCardVisPileLow() {
    KlondikeModel km = makeKM();
    List<Card> cs = makeDeck(Arrays.asList("A♡", "A♢", "A♣", "A♠"));
    km.startGame(cs, false, 2, 1);
    Assert.assertThrows("Pile Num Low",
            IllegalArgumentException.class, () -> km.getCardAt(-1, 0));
  }

  /**
   * Checks that getCardAt throws an ISE if the game has not been started.
   */
  @Test
  public void checkGetCardAtNotStarted() {
    KlondikeModel km = makeKM();
    Assert.assertThrows("Game not started",
            IllegalStateException.class, () -> km.getCardAt(0, 0));
  }

  /**
   * Checks that getCardAT throws an IAE if the pileNum is negative.
   */
  @Test
  public void checkGetCardAtPileLow() {
    KlondikeModel km = makeKM();
    List<Card> cs = makeDeck(Arrays.asList("A♡", "A♢", "A♣", "A♠"));
    km.startGame(cs, false, 2, 1);
    Assert.assertThrows("Pile Num Low",
            IllegalArgumentException.class, () -> km.getCardAt(-1, 0));
  }

  /**
   * Checks that getCardAt is zero-based and throws an IAE if the card
   * is equal to the pile's height.
   */
  @Test
  public void checkGetCardAtCardZeroBased() {
    KlondikeModel km = makeKM();
    List<Card> cs = makeDeck(Arrays.asList("A♡", "A♢", "A♣", "A♠"));
    km.startGame(cs, false, 2, 1);
    Assert.assertThrows("Card Num High",
            IllegalArgumentException.class, () -> km.getCardAt(0, 1));
  }

  /**
   * Checks that getCardAt is zero-based and throws an IAE if the pileNum
   * is equal to the number of piles.
   */
  @Test
  public void checkGetCardAtPileZeroBased() {
    KlondikeModel km = makeKM();
    List<Card> cs = makeDeck(Arrays.asList("A♡", "A♢", "A♣", "A♠"));
    km.startGame(cs, false, 2, 1);
    Assert.assertThrows("Pile Num High",
            IllegalArgumentException.class, () -> km.getCardAt(2, 0));
  }

  /**
   * Checks that getCardAt throws an IAE if the card is negative.
   */
  @Test
  public void checkGetCardAtCardLow() {
    KlondikeModel km = makeKM();
    List<Card> cs = makeDeck(Arrays.asList("A♡", "A♢", "A♣", "A♠"));
    km.startGame(cs, false, 2, 1);
    Assert.assertThrows("Card Num Low",
            IllegalArgumentException.class, () -> km.getCardAt(0, -1));
  }

  /**
   * Checks that getCardAtFound throws an ISE if the game hasnt been started.
   */
  @Test
  public void checkGetCardAtFoundNotStarted() {
    KlondikeModel km = makeKM();
    Assert.assertThrows("Game not started",
            IllegalStateException.class, () -> km.getCardAt(0));
  }

  /**
   * Checks that the foundation pile number is zero-based and throws an IAE if the number is
   * equal to the number of foundation piles.
   */
  @Test
  public void checkGetCardAtFoundZeroBased() {
    KlondikeModel km = makeKM();
    List<Card> cs = makeDeck(Arrays.asList("A♡", "A♢", "A♣", "A♠"));
    km.startGame(cs, false, 2, 1);
    Assert.assertThrows("Pile Num High",
            IllegalArgumentException.class, () -> km.getCardAt(4));
  }

  /**
   * Checks that getCardAtFound throws an IAE if the pileNum is negative.
   */
  @Test
  public void checkGetCardAtFoundLow() {
    KlondikeModel km = makeKM();
    List<Card> cs = makeDeck(Arrays.asList("A♡", "A♢", "A♣", "A♠"));
    km.startGame(cs, false, 2, 1);
    Assert.assertThrows("Card Num Low",
            IllegalArgumentException.class, () -> km.getCardAt(-1));
  }

  /**
   * Checks that getCardAtFound returns null if the pile is empty.
   */
  @Test
  public void checkGetCardAtFoundNull() {
    KlondikeModel km = makeKM();
    km.startGame(km.getDeck(), false, 2, 1);
    Assert.assertEquals(null, km.getCardAt(0));
  }

  /**
   * Checks that getCardAtFound returns the correct card.
   */
  @Test
  public void checkGetCardAtFoundCard() {
    KlondikeModel km = makeKM();
    List<Card> cs = makeDeck(Arrays.asList("A♡", "A♢", "A♣", "A♠"));
    km.startGame(cs, false, 2, 1);
    km.moveDrawToFoundation(0);
    Assert.assertEquals("A♠", km.getCardAt(0).toString());
  }

  /**
   * Checks that getDraw throws an ISE if the game has not been started.
   */
  @Test
  public void checkGetDrawCardsNotStarted() {
    KlondikeModel km = makeKM();
    Assert.assertThrows("Game not started",
            IllegalStateException.class, () -> km.getDrawCards());
  }

  /**
   * Checks that getDrawCards returns an alias and is immutable.
   */
  @Test
  public void checkGetDrawCardsImmutable() {
    KlondikeModel km = makeKM();
    km.startGame(km.getDeck(), false, 2, 1);
    List<Card> cs = km.getDrawCards();
    cs.remove(0);
    Assert.assertNotEquals(km.getDrawCards(), cs);
  }

  /**
   * Checks that getDrawCards is the size it should be.
   */
  @Test
  public void checkGetDrawCardsCorrectSize() {
    KlondikeModel km = makeKM();
    km.startGame(km.getDeck(), false, 2, 1);
    Assert.assertEquals(1, km.getDrawCards().size());
  }

  /**
   * Checks that cards that move out of the draw pile actually get removed from the pile.
   */
  @Test
  public void checkGetDrawCardsGetsSmaller() {
    KlondikeModel km = makeKM();
    List<Card> cs = makeDeck(Arrays.asList("A♡", "A♢", "A♣", "A♠"));
    km.startGame(cs, false, 2, 1);
    Assert.assertEquals(1, km.getDrawCards().size());
    km.moveDrawToFoundation(0);
    Assert.assertEquals(0, km.getDrawCards().size());
  }

  /**
   * Checks that getDrawCards returns the cards in the appropriate order.
   */
  @Test
  public void checkGetDrawCardsCorrectOrder() {
    KlondikeModel km = makeKM();
    List<Card> cs = makeDeck(Arrays.asList("A♡", "A♢", "A♣", "A♠"));
    km.startGame(cs, false, 1, 3);
    Assert.assertEquals(makeDeck(Arrays.asList("A♢", "A♣", "A♠")), km.getDrawCards());
  }

  /**
   * Checks that getNumFoundations throws an ISE if the game has not been started.
   */
  @Test
  public void checkGetNumFoundsNotStarted() {
    KlondikeModel km = makeKM();
    Assert.assertThrows("Game not started",
            IllegalStateException.class, () -> km.getNumFoundations());
  }

  /**
   * Checks that getNumFoundations starts out at the correct value even if the piles are empty.
   */
  @Test
  public void checkGetNumFoundsCorrectStart() {
    KlondikeModel km = makeKM();
    km.startGame(km.getDeck(), false, 2, 1);
    Assert.assertEquals(4, km.getNumFoundations());
  }

  /**
   * Checks that getNumFoundations remains the same regardless of cards added to it.
   */
  @Test
  public void checkGetNumFoundsCorrectThroughout() {
    KlondikeModel km = makeKM();
    List<Card> cs = makeDeck(Arrays.asList("A♡", "A♢", "A♣", "A♠"));
    km.startGame(cs, false, 2, 1);
    km.moveDrawToFoundation(0);
    km.moveToFoundation(0, 1);
    Assert.assertEquals(4, km.getNumFoundations());
  }
}
