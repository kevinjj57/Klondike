package cs3500.klondike;

import org.junit.Assert;

import java.util.Arrays;
import java.util.List;

import cs3500.klondike.model.hw02.Card;
import cs3500.klondike.model.hw02.KlondikeModel;
import cs3500.klondike.model.hw04.KlondikeCreator;
import cs3500.klondike.view.KlondikeTextualView;

/**
 * Tests for the use of KlondikeTextualView on a Whitehead.
 */
public class TestKTVWhitehead extends TestKTV {

  @Override
  protected KlondikeModel makeKM() {
    return KlondikeCreator.create(KlondikeCreator.GameType.WHITEHEAD);
  }

  /**
   * Tests that the CascadePiles Display face-upas expected for all WhiteheadKlondike.
   */
  @Override
  public void testCascade() {
    StringBuffer sb = new StringBuffer();
    KlondikeModel km = makeKM();
    KlondikeTextualView ktv = ktv(km, sb);
    List<Card> cs = makeDeck(Arrays.asList(
            "A♡", "A♢", "A♣", "A♠",
            "A♡", "A♢", "A♣", "A♠",
            "A♡", "A♢", "A♣", "A♠"));
    km.startGame(cs, false, 4, 1);
    String act = ktv.toString();
    String exp =
            "Draw: A♣\n" +
                    "Foundation: <none>, <none>, <none>, <none>, <none>, <none>, <none>, " +
                    "<none>, <none>, <none>, <none>, <none>\n" +
                    " A♡ A♢ A♣ A♠\n" +
                    "    A♡ A♢ A♣\n" +
                    "       A♠ A♡\n" +
                    "          A♢";
    Assert.assertEquals(exp, act);
  }
}
