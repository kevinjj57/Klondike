package cs3500.klondike;

import cs3500.klondike.model.hw02.BasicKlondike;
import cs3500.klondike.model.hw02.Card;

import java.util.ArrayList;
import java.util.List;
import org.junit.Assert;
import org.junit.Test;

import java.util.Arrays;

/**
 * Testing cases used in Examplar.
 */
public class ExamplarModelTests {

  private BasicKlondike bk = new BasicKlondike();
  //Algebraic equation calculating the maximum number of Cascade piles for a given number of cards
  //cast as an int because it always returns a whole number
  private final int MaxNumPiles =
          (int) Math.floor(Math.sqrt((2 * bk.getDeck().size()) + 0.25) - 0.5);

  /**
   * resets the baseKondike for each test.
   */
  private void reset() {
    bk = new BasicKlondike();
  }

  /**
   * gets the value of a requested card.
   *
   * @throws NumberFormatException if the first value is not one of the traditional A-K values.
   */

  private List<String> getDeckAsStrings() {
    List<Card> temp = bk.getDeck();
    List<String> temp2 = Arrays.asList();
    int i = 0;
    for (Card c : temp) {
      temp2.set(i, c.toString());
      i++;
    }
    return temp2;
  }

  private List<Card> placeCards() {
    reset();
    List<Card> temp = bk.getDeck();
    List<Card> newf = List.of(new Card[52]);
    int i = 0;
    int val = 1;
    int suit = 1;
    for (Card c : bk.getDeck()) {
      newf.set(i, bk.getDeck().get(getIndexOf(getNum(val) + suitNum(suit))));
      i++;
      if (val == 13) {
        val = 1;
        suit++;
      } else {
        val++;
      }
    }
    return newf;
  }

  private int getIndexOf(String s) {
    reset();
    int i = 0;
    for (Card c : bk.getDeck()) {
      if (c.toString().equals(s)) {
        return i;
      }
      i++;
    }
    throw new IllegalArgumentException();
  }

  private List<Card> makeDeck(List<String> strings) {
    reset();
    List<Card> ans = new ArrayList<Card>();
    for (String s : strings) {
      for (Card c : bk.getDeck()) {
        if (c.toString().equals(s)) {
          ans.add(c);
        }
      }
    }
    return ans;
  }


  private Card getCard(String s) {
    reset();
    int i = 0;
    for (Card c : bk.getDeck()) {
      if (c.toString().equals(s)) {
        return bk.getDeck().get(i);
      }
      i++;
    }
    throw new IllegalArgumentException("Card not in deck");
  }

  private String getNum(int i) {
    if (i == 1) {
      return "A";
    } else if (i == 11) {
      return "J";
    } else if (i == 12) {
      return "Q";
    } else if (i == 13) {
      return "K";
    } else {
      return "" + i;
    }
  }

  private String suitNum(int i) {
    if (i == 1) {
      return "♡";
    } else if (i == 2) {
      return "♢";
    } else if (i == 3) {
      return "♣";
    } else if (i == 4) {
      return "♠";
    }
    return null;
  }

  private int getVal(Card c) {
    String x = c.toString().substring(0, 1);
    if (x.equals("A")) {
      return 1;
    } else if (x.equals("J")) {
      return 11;
    } else if (x.equals("Q")) {
      return 12;
    } else if (x.equals("K")) {
      return 13;
    } else {
      return Integer.parseInt(x);
    }
  }

  /**
   * gets the color of the card.
   *
   * @throws IllegalArgumentException if the suit on the card is not one of the four standard.
   */

  private String getColor(Card c) {
    String x = c.toString().substring(1, 2);
    if (x.equals("♡") || x.equals("♢")) {
      return "red";
    } else if (x.equals("♣") || x.equals("♠")) {
      return "black";
    } else {
      throw new IllegalArgumentException("Bad Suit");
    }
  }

  private int numFoundPiles() {
    reset();
    bk.getDeck().stream().filter(c -> (getVal(c) != 1));
    return bk.getDeck().size();
  }

  private int currentNumInDest() {
    int i = MaxNumPiles - 1;
    int c = 0;
    int ans = 0;
    while (i >= 0) {
      ans += bk.getPileHeight(i);
      i--;
    }
    return ans;
  }

  /**
   * Tests to make sure movepile does not allow a non-king to move to an empty pile.
   */
  @Test
  public void testNonKingMovement() {
    reset();
    List<Card> cs = makeDeck(Arrays.asList("A♡", "A♢", "A♣", "A♠"));
    bk.startGame(cs, false, 2, 1);
    bk.moveToFoundation(0, 0);
    Assert.assertThrows("Can't move a non king",
            IllegalStateException.class, () -> bk.movePile(1, 1, 0));
  }

  /**
   * Tests to make sure the game is over when all the cards have moved up.
   */
  @Test
  public void testGameOver() {
    reset();
    List<Card> cs = makeDeck(Arrays.asList("A♡", "A♢", "A♣", "A♠"));
    bk.startGame(cs, false, 2, 1);
    boolean beginning = bk.isGameOver();
    bk.moveToFoundation(0, 0);
    bk.moveToFoundation(1, 1);
    bk.moveToFoundation(1, 2);
    bk.moveDrawToFoundation(3);
    boolean end = bk.isGameOver();
    Assert.assertNotEquals(beginning, end);
  }

  /**
   * Tests to make sure cards are visable after movement.
   */
  @Test
  public void testCardVis() {
    reset();
    List<Card> cs = makeDeck(Arrays.asList(
            "2♡", "A♢", "A♣", "A♠",
            "A♡", "2♢", "2♣", "2♠"));
    bk.startGame(cs, false, 2, 1);
    bk.discardDraw();
    bk.discardDraw();
    bk.discardDraw();
    bk.discardDraw();
    bk.discardDraw();
    bk.moveDraw(0);
    boolean ans = bk.isCardVisible(0, 0) && bk.isCardVisible(0, 1);
    Assert.assertTrue(ans);
  }
}