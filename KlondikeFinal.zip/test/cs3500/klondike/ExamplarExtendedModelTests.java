package cs3500.klondike;

import cs3500.klondike.model.hw02.BasicKlondike;
import cs3500.klondike.model.hw02.Card;
import cs3500.klondike.model.hw04.WhiteheadKlondike;
import cs3500.klondike.model.hw04.LimitedDrawKlondike;

import org.junit.Assert;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * ExamplarTests for Whitehead and Limited Klondike Models.
 */
public class ExamplarExtendedModelTests {

  private BasicKlondike bk = new BasicKlondike();
  private WhiteheadKlondike wk = new WhiteheadKlondike();

  /**
   * resets the baseKlondike for each test.
   */
  private void resetBK() {
    bk = new BasicKlondike();
  }

  /**
   * resets the whiteKlondike for each test.
   */
  private void resetWK() {
    wk = new WhiteheadKlondike();
  }


  private List<Card> makeDeck(List<String> strings) {
    resetBK();
    List<Card> ans = new ArrayList<Card>();
    for (String s : strings) {
      for (Card c : bk.getDeck()) {
        if (c.toString().equals(s)) {
          ans.add(c);
        }
      }
    }
    return ans;
  }

  @Test
  public void testDiscardLDK() {
    LimitedDrawKlondike ldk = new LimitedDrawKlondike(0);
    List<Card> cs = makeDeck(Arrays.asList("A♡", "A♢", "A♣", "A♠"));
    ldk.startGame(cs, false, 2, 1);
    ldk.discardDraw();
    Assert.assertEquals(0, ldk.getDrawCards().size());
  }

  @Test
  public void testDiscardSizeLDK() {
    LimitedDrawKlondike ldk = new LimitedDrawKlondike(2);
    List<Card> cs = makeDeck(Arrays.asList("A♡", "A♢", "A♣", "A♠"));
    ldk.startGame(cs, false, 2, 1);
    Assert.assertEquals(1, ldk.getDrawCards().size());
    ldk.discardDraw();
    Assert.assertEquals(1, ldk.getDrawCards().size());
    ldk.discardDraw();
    Assert.assertEquals(1, ldk.getDrawCards().size());
    ldk.discardDraw();
    Assert.assertEquals(0, ldk.getDrawCards().size());
  }

  @Test
  public void testDiffColorMoveDrawThrowsWK() {
    resetWK();
    List<Card> cs = makeDeck(Arrays.asList(
            "2♡", "A♢", "A♣", "A♠",
            "A♡", "2♢", "2♣", "2♠"));
    wk.startGame(cs, false, 2, 1);
    Assert.assertThrows("Piles must be same color",
            IllegalStateException.class, () -> wk.moveDraw(0));
  }

  @Test
  public void testMoveAnyCardToMtWK() {
    resetWK();
    List<Card> cs = makeDeck(Arrays.asList("A♡", "A♢", "A♣", "A♠"));
    wk.startGame(cs, false, 2, 1);
    wk.moveToFoundation(0, 0);
    wk.moveDraw(0);
    Assert.assertEquals(1, wk.getPileHeight(0));
  }


  @Test
  public void testMultMoveDiffSuitWK() {
    resetWK();
    List<Card> cs = makeDeck(Arrays.asList(
            "A♡", "A♢", "2♣", "A♠",
            "2♡", "2♢", "A♣", "2♠"));
    wk.startGame(cs, false, 2, 1);
    wk.moveToFoundation(0, 0);
    wk.moveDraw(1);
    Assert.assertThrows("All moving cards must be same suit, not just color",
            IllegalStateException.class, () -> wk.movePile(1, 2, 0));
  }
}
