package cs3500.klondike;

import cs3500.klondike.model.hw02.KlondikeModel;
import cs3500.klondike.model.hw04.KlondikeCreator;

/**
 * Tests the extended Whitehead Klondike Model.
 */
public class TestModelWhitehead extends TestModel {

  protected KlondikeModel makeKM() {
    return KlondikeCreator.create(KlondikeCreator.GameType.WHITEHEAD);
  }
}
