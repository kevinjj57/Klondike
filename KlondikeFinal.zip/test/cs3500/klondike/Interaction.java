package cs3500.klondike;

/**
 * A helper interface to test more efficiently.
 */
public interface Interaction {

  void apply(StringBuilder in, StringBuilder out);
}
