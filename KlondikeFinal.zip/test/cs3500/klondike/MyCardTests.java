package cs3500.klondike;

import org.junit.Assert;
import org.junit.Test;
import cs3500.klondike.model.hw02.MyCard;

/**
 * Testing for MyCard.
 */
public class MyCardTests {


  /**
   * Test to ensure myString of MyCard works as expected.
   */
  @Test
  public void testToStringMyCard() {
    MyCard c1 = new MyCard(MyCard.CardVal.ACE, MyCard.Suit.CLUBS);
    MyCard c7 = new MyCard(MyCard.CardVal.SEVEN, MyCard.Suit.DIAMONDS);
    MyCard c11 = new MyCard(MyCard.CardVal.JACK, MyCard.Suit.SPADES);
    MyCard c12 = new MyCard(MyCard.CardVal.QUEEN, MyCard.Suit.HEARTS);
    MyCard c13 = new MyCard(MyCard.CardVal.KING, MyCard.Suit.CLUBS);
    Assert.assertEquals("A♣", c1.toString());
    Assert.assertEquals("7♢", c7.toString());
    Assert.assertEquals("J♠", c11.toString());
    Assert.assertEquals("Q♡", c12.toString());
    Assert.assertEquals("K♣", c13.toString());
  }
}