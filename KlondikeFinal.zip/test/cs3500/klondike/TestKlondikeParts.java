package cs3500.klondike;

import java.util.ArrayList;
import java.util.List;

import cs3500.klondike.model.hw02.Card;
import cs3500.klondike.model.hw02.KlondikeModel;

/**
 * A testing class designed to be extended that prevents repitition of code.
 * Requires all extensions specify their Klondike Model in makeKM
 * and allows makeDeck to be accessed by all classes.
 */
public abstract class TestKlondikeParts {

  protected abstract KlondikeModel makeKM();

  /**
   * A helper test method for making a custom deck. Give a List of Strings exactly as the card
   * you with to make would appear in its toString method.
   * @param strings the toString representation of the cards you wish to make.
   * @return a deck of cards containing the cards you asked for.
   */
  protected final List<Card> makeDeck(List<String> strings) {
    KlondikeModel km = makeKM();
    List<Card> ans = new ArrayList<Card>();
    for (String s : strings) {
      for (Card c : km.getDeck()) {
        if (c.toString().equals(s)) {
          ans.add(c);
        }
      }
    }
    return ans;
  }
}
