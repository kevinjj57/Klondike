package cs3500.klondike;

import org.junit.Assert;
import org.junit.Test;

import java.io.StringReader;
import java.util.Arrays;
import java.util.List;

import cs3500.klondike.controller.KlondikeTextualController;
import cs3500.klondike.model.hw02.Card;
import cs3500.klondike.model.hw02.KlondikeModel;

/**
 * Abstract class used for testing against the Klondike Model interface. Tests should pass
 * for all models.
 */
public abstract class TestController extends TestKlondikeParts {

  protected final StringReader input(String s) {
    return new StringReader(s);
  }

  protected final StringBuilder output() {
    return new StringBuilder();
  }

  protected final KlondikeTextualController ktc(StringReader in, StringBuilder out) {
    return new KlondikeTextualController(in, out);
  }

  /**
   * Test that a null model gets an IAE.
   */
  @Test
  public void testNullModel() {
    StringReader in = input("");
    StringBuilder out = output();
    KlondikeTextualController ktc = ktc(in,out);
    KlondikeModel km = makeKM();
    Assert.assertThrows(IllegalArgumentException.class, () -> ktc.playGame(
            null, km.getDeck(), false, 1, 1));
  }

  /**
   * Test that a null Appendable gets an IAE.
   */
  @Test
  public void testNullOut() {
    StringReader in = input("");
    KlondikeTextualController ktc = ktc(in, null);
    KlondikeModel km = makeKM();
    Assert.assertThrows(IllegalArgumentException.class, () -> ktc.playGame(
            km, km.getDeck(), false, 1, 1));
  }

  /**
   * Test that a null Readable gets an IAE.
   */
  @Test
  public void testNullIn() {
    StringBuilder out = output();
    KlondikeTextualController ktc = ktc(null, out);
    KlondikeModel km = makeKM();
    Assert.assertThrows(IllegalArgumentException.class, () -> ktc.playGame(
            km, km.getDeck(), false, 1, 1));
  }

  /**
   * Test that low numPileArgument gets an ISE.
   */
  @Test
  public void testLowNumPileISE() {
    StringReader in = input("");
    StringBuilder out = output();
    KlondikeTextualController ktc = ktc(in, out);
    KlondikeModel km = makeKM();
    Assert.assertThrows(IllegalStateException.class, () -> ktc.playGame(
            km, km.getDeck(), false, 0, 1));
  }

  /**
   * Test that bad numPileArgument gets an ISE.
   */
  @Test
  public void testHighNumPileISE() {
    StringReader in = input("");
    StringBuilder out = output();
    KlondikeTextualController ktc = ktc(in, out);
    KlondikeModel km = makeKM();
    Assert.assertThrows(IllegalStateException.class, () -> ktc.playGame(
            km, km.getDeck(), false, 100, 1));
  }

  /**
   * Test that bad numDrawArgument gets an ISE.
   */
  @Test
  public void testLowNumDrawISE() {
    StringReader in = input("");
    StringBuilder out = output();
    KlondikeTextualController ktc = ktc(in, out);
    KlondikeModel km = makeKM();
    Assert.assertThrows(IllegalStateException.class, () -> ktc.playGame(
            km, km.getDeck(), false, 1, 0));
  }

  /**
   * Test that a null deck gets an ISE.
   */
  @Test
  public void testNullDeckISE() {
    StringReader in = input("");
    StringBuilder out = output();
    KlondikeTextualController ktc = ktc(in, out);
    KlondikeModel km = makeKM();
    Assert.assertThrows(IllegalStateException.class, () -> ktc.playGame(
            km, null, false, 1, 1));
  }

  /**
   * Test that an Illegal deck gets an ISE.
   */
  @Test
  public void testIllegalDeckISE() {
    StringReader in = input("");
    StringBuilder out = output();
    KlondikeTextualController ktc = ktc(in, out);
    KlondikeModel km = makeKM();
    List<Card> cs = makeDeck(Arrays.asList("A♡", "A♢", "A♣"));
    Assert.assertThrows(IllegalStateException.class, () -> ktc.playGame(
            km, cs, false, 1, 1));
  }

  /**
   * Test that an empty Readable throws an ISE.
   */
  @Test
  public void testMtReadableISE() {
    StringReader in = input("");
    StringBuilder out = output();
    KlondikeTextualController ktc = ktc(in, out);
    KlondikeModel km = makeKM();
    Assert.assertThrows(IllegalStateException.class, () -> ktc.playGame(
            km, km.getDeck(), false, 1, 1));
  }

  /**
   * Tests that score prints when quit.
   */
  @Test
  public void testScoreWhenQuit() {
    StringReader in = input("q");
    StringBuilder out = output();
    KlondikeTextualController ktc = ktc(in, out);
    KlondikeModel km = makeKM();
    ktc.playGame(km, km.getDeck(), false, 1, 1);
    String act = out.toString();
    String exp = "Score: 0\n";
    Assert.assertTrue(act.contains(exp));
  }


  /**
   * Test that random words state an invalid move instead of throwing an ISE.
   */
  @Test
  public void testWords() {
    StringReader in = input("word q");
    StringBuilder out = output();
    KlondikeTextualController ktc = ktc(in, out);
    KlondikeModel km = makeKM();
    ktc.playGame(km, km.getDeck(), false, 1, 1);
    String act = out.toString();
    String exp =
            "Invalid move. Play again. Must call one of the five available methods or end game.";
    Assert.assertTrue(act.contains(exp));
  }

  /**
   * Tests that movePile followed by a word states invalid move.
   */
  @Test
  public void testMPPIgnoresWords() {
    StringReader in = input("mpp word q");
    StringBuilder out = output();
    KlondikeTextualController ktc = ktc(in, out);
    KlondikeModel km = makeKM();
    ktc.playGame(km, km.getDeck(), false, 1, 1);
    String act = out.toString();
    String exp =
            "Invalid move. Play again.";
    Assert.assertFalse(act.contains(exp));
  }

  /**
   * Tests that you can quit mid movePile move during src.
   */
  @Test
  public void testQuitMidMppSrc() {
    StringReader in = input("mpp q");
    StringBuilder out = output();
    KlondikeTextualController ktc = ktc(in, out);
    KlondikeModel km = makeKM();
    ktc.playGame(km, km.getDeck(), false, 1, 1);
    String act = out.toString();
    String exp =
            "Game quit!\nState of game when quit:\n";
    Assert.assertTrue(act.contains(exp));
  }

  /**
   * Tests that you can quit mid movePile move during pileNum.
   */
  @Test
  public void testQuitMidMppNumCards() {
    StringReader in = input("mpp 1 q");
    StringBuilder out = output();
    KlondikeTextualController ktc = ktc(in, out);
    KlondikeModel km = makeKM();
    ktc.playGame(km, km.getDeck(), false, 1, 1);
    String act = out.toString();
    String exp =
            "Game quit!\nState of game when quit:\n";
    Assert.assertTrue(act.contains(exp));
  }

  /**
   * Tests that you can quit mid movePile move during destPile.
   */
  @Test
  public void testQuitMidMppdestPile() {
    StringReader in = input("mpp 1 1 q");
    StringBuilder out = output();
    KlondikeTextualController ktc = ktc(in, out);
    KlondikeModel km = makeKM();
    ktc.playGame(km, km.getDeck(), false, 1, 1);
    String act = out.toString();
    String exp =
            "Game quit!\nState of game when quit:\n";
    Assert.assertTrue(act.contains(exp));
  }

  /**
   * Tests that an illegal movePile move states that the move is illegal.
   */
  @Test
  public void testMppIllegalMove() {
    StringReader in = input("mpp 1 1 2 q");
    StringBuilder out = output();
    KlondikeTextualController ktc = ktc(in, out);
    KlondikeModel km = makeKM();
    ktc.playGame(km, km.getDeck(), false, 2, 1);
    String act = out.toString();
    String exp =
            "Move not allowed.";
    Assert.assertTrue(act.contains(exp));
  }

  /**
   * Tests that an illegal movePile args (src low) states that the args are illegal.
   */
  @Test
  public void testMppIllegalArgsSrcLow() {
    StringReader in = input("mpp -1 1 2 q");
    StringBuilder out = output();
    KlondikeTextualController ktc = ktc(in, out);
    KlondikeModel km = makeKM();
    ktc.playGame(km, km.getDeck(), false, 2, 1);
    String act = out.toString();
    String exp =
            "Bad move pile values.";
    Assert.assertTrue(act.contains(exp));
  }

  /**
   * Tests that an illegal movePile args (src high) states that the args are illegal.
   */
  @Test
  public void testMppIllegalArgsSrcHigh() {
    StringReader in = input("mpp 10 1 2 q");
    StringBuilder out = output();
    KlondikeTextualController ktc = ktc(in, out);
    KlondikeModel km = makeKM();
    ktc.playGame(km, km.getDeck(), false, 2, 1);
    String act = out.toString();
    String exp =
            "Bad move pile values.";
    Assert.assertTrue(act.contains(exp));
  }

  /**
   * Tests that an illegal movePile args (numCards low) states that the args are illegal.
   */
  @Test
  public void testMppIllegalArgsNumCardLow() {
    StringReader in = input("mpp 1 0 2 q");
    StringBuilder out = output();
    KlondikeTextualController ktc = ktc(in, out);
    KlondikeModel km = makeKM();
    ktc.playGame(km, km.getDeck(), false, 2, 1);
    String act = out.toString();
    String exp =
            "Bad move pile values.";
    Assert.assertTrue(act.contains(exp));
  }

  /**
   * Tests that an illegal movePile args (numCards high) states that the args are illegal.
   */
  @Test
  public void testMppIllegalArgsNumCardHigh() {
    StringReader in = input("mpp 1 10 2 q");
    StringBuilder out = output();
    KlondikeTextualController ktc = ktc(in, out);
    KlondikeModel km = makeKM();
    ktc.playGame(km, km.getDeck(), false, 2, 1);
    String act = out.toString();
    String exp =
            "Bad move pile values.";
    Assert.assertTrue(act.contains(exp));
  }

  /**
   * Tests that an illegal movePile args (destPile low) states that the args are illegal.
   */
  @Test
  public void testMppIllegalArgsDestLow() {
    StringReader in = input("mpp 1 1 -1 q");
    StringBuilder out = output();
    KlondikeTextualController ktc = ktc(in, out);
    KlondikeModel km = makeKM();
    ktc.playGame(km, km.getDeck(), false, 2, 1);
    String act = out.toString();
    String exp =
            "Bad move pile values.";
    Assert.assertTrue(act.contains(exp));
  }

  /**
   * Tests that an illegal movePile args (destPile high) states that the args are illegal.
   */
  @Test
  public void testMppIllegalArgsDestHigh() {
    StringReader in = input("mpp 1 1 10 q");
    StringBuilder out = output();
    KlondikeTextualController ktc = ktc(in, out);
    KlondikeModel km = makeKM();
    ktc.playGame(km, km.getDeck(), false, 2, 1);
    String act = out.toString();
    String exp =
            "Bad move pile values.";
    Assert.assertTrue(act.contains(exp));
  }

  /**
   * Tests that a movePile works.
   */
  @Test
  public void testMppWorks() {
    StringReader in = input("mpf 1 1 mpp 2 1 1 q");
    StringBuilder out = output();
    KlondikeTextualController ktc = ktc(in, out);
    KlondikeModel km = makeKM();
    List<Card> cs = makeDeck(
            Arrays.asList(
                    "A♡", "A♢", "K♣", "A♠",
                    "2♡", "2♢", "2♣", "2♠",
                    "3♡", "3♢", "3♣", "3♠",
                    "4♡", "4♢", "4♣", "4♠",
                    "5♡", "5♢", "5♣", "5♠",
                    "6♡", "6♢", "6♣", "6♠",
                    "7♡", "7♢", "7♣", "7♠",
                    "8♡", "8♢", "8♣", "8♠",
                    "9♡", "9♢", "9♣", "9♠",
                    "10♡", "10♢", "10♣", "10♠",
                    "J♡", "J♢", "J♣", "J♠",
                    "Q♡", "Q♢", "Q♣", "Q♠",
                    "K♡", "K♢", "A♣", "K♠"));
    ktc.playGame(km, cs, false, 2, 1);
    String act = out.toString();
    String exp =
            " K♣ A♢\n";
    Assert.assertTrue(act.contains(exp));
    Assert.assertEquals(1, km.getPileHeight(0));
    Assert.assertEquals(1, km.getPileHeight(1));
  }

  /**
   * Tests that a movePile works even with random words entered..
   */
  @Test
  public void testMppWorksWithRandomWords() {
    StringReader in = input("mpf 1 1 mpp  dd    d 2 s d g 1  e 1 q");
    StringBuilder out = output();
    KlondikeTextualController ktc = ktc(in, out);
    KlondikeModel km = makeKM();
    List<Card> cs = makeDeck(
            Arrays.asList(
                    "A♡", "A♢", "K♣", "A♠",
                    "2♡", "2♢", "2♣", "2♠",
                    "3♡", "3♢", "3♣", "3♠",
                    "4♡", "4♢", "4♣", "4♠",
                    "5♡", "5♢", "5♣", "5♠",
                    "6♡", "6♢", "6♣", "6♠",
                    "7♡", "7♢", "7♣", "7♠",
                    "8♡", "8♢", "8♣", "8♠",
                    "9♡", "9♢", "9♣", "9♠",
                    "10♡", "10♢", "10♣", "10♠",
                    "J♡", "J♢", "J♣", "J♠",
                    "Q♡", "Q♢", "Q♣", "Q♠",
                    "K♡", "K♢", "A♣", "K♠"));
    ktc.playGame(km, cs, false, 2, 1);
    String act = out.toString();
    String exp =
            " K♣ A♢\n";
    Assert.assertTrue(act.contains(exp));
    Assert.assertEquals(1, km.getPileHeight(0));
    Assert.assertEquals(1, km.getPileHeight(1));
  }

  /**
   * Tests that you can quit mid moveDraw move during destPile.
   */
  @Test
  public void testQuitMidMdDestPile() {
    StringReader in = input("md q");
    StringBuilder out = output();
    KlondikeTextualController ktc = ktc(in, out);
    KlondikeModel km = makeKM();
    ktc.playGame(km, km.getDeck(), false, 1, 1);
    String act = out.toString();
    String exp =
            "Game quit!\nState of game when quit:\n";
    Assert.assertTrue(act.contains(exp));
  }

  /**
   * Tests that a low destPile number states an illegal move.
   */
  @Test
  public void testMdDestPileLow() {
    StringReader in = input("md -1 q");
    StringBuilder out = output();
    KlondikeTextualController ktc = ktc(in, out);
    KlondikeModel km = makeKM();
    ktc.playGame(km, km.getDeck(), false, 1, 1);
    String act = out.toString();
    String exp = "Bad move draw value.";
    Assert.assertTrue(act.contains(exp));
  }

  /**
   * Tests that a low destPile number states an illegal move.
   */
  @Test
  public void testMdDestPileHigh() {
    StringReader in = input("md 2 q");
    StringBuilder out = output();
    KlondikeTextualController ktc = ktc(in, out);
    KlondikeModel km = makeKM();
    ktc.playGame(km, km.getDeck(), false, 1, 1);
    String act = out.toString();
    String exp = "Bad move draw value.";
    Assert.assertTrue(act.contains(exp));
  }

  /**
   * Tests that a low destPile number states an illegal move.
   */
  @Test
  public void testMdIllegalMove() {
    StringReader in = input("md 1 q");
    StringBuilder out = output();
    KlondikeTextualController ktc = ktc(in, out);
    KlondikeModel km = makeKM();
    List<Card> cs = makeDeck(Arrays.asList("A♡", "A♢", "A♣", "A♠"));
    ktc.playGame(km, cs, false, 1, 1);
    String act = out.toString();
    String exp = "Move not allowed.";
    Assert.assertTrue(act.contains(exp));
  }

  /**
   * Tests that the game can be quit from the mpf src pile position.
   */
  @Test
  public void testQuitMidMpfSrc() {
    StringReader in = input("mpf q");
    StringBuilder out = output();
    KlondikeTextualController ktc = ktc(in, out);
    KlondikeModel km = makeKM();
    ktc.playGame(km, km.getDeck(), false, 1, 1);
    String act = out.toString();
    String exp = "Game quit!\nState of game when quit:\n";
    Assert.assertTrue(act.contains(exp));
  }

  /**
   * Tests that the game can be quit from the mpf found pile position.
   */
  @Test
  public void testQuitMidMpfFound() {
    StringReader in = input("mpf 1 q");
    StringBuilder out = output();
    KlondikeTextualController ktc = ktc(in, out);
    KlondikeModel km = makeKM();
    ktc.playGame(km, km.getDeck(), false, 1, 1);
    String act = out.toString();
    String exp = "Game quit!\nState of game when quit:\n";
    Assert.assertTrue(act.contains(exp));
  }

  /**
   * Tests that valid arguments actually moves the card.
   */
  @Test
  public void testMpfFoundWorks() {
    StringReader in = input("mpf 1 1 q");
    StringBuilder out = output();
    KlondikeTextualController ktc = ktc(in, out);
    KlondikeModel km = makeKM();
    List<Card> cs = makeDeck(Arrays.asList("A♡", "A♢", "A♣", "A♠"));
    ktc.playGame(km, cs, false, 1, 1);
    String act = out.toString();
    String exp = "Foundation: A♡, <none>, <none>, <none>\n";
    Assert.assertTrue(act.contains(exp));
  }

  /**
   * Tests that valid arguments actually moves the card even if you
   * have random letters in the middle.
   */
  @Test
  public void testMpfFoundWorksWithWords() {
    StringReader in = input("mpf w w t 1 ss s 1 q");
    StringBuilder out = output();
    KlondikeTextualController ktc = ktc(in, out);
    KlondikeModel km = makeKM();
    List<Card> cs = makeDeck(Arrays.asList("A♡", "A♢", "A♣", "A♠"));
    ktc.playGame(km, cs, false, 1, 1);
    String act = out.toString();
    String exp = "Foundation: A♡, <none>, <none>, <none>\n";
    Assert.assertTrue(act.contains(exp));
  }

  /**
   * Tests that a low srcPile number in mpf states illegal move.
   */
  @Test
  public void testMpfLowSrc() {
    StringReader in = input("mpf -1 1 q");
    StringBuilder out = output();
    KlondikeTextualController ktc = ktc(in, out);
    KlondikeModel km = makeKM();
    ktc.playGame(km, km.getDeck(), false, 1, 1);
    String act = out.toString();
    String exp = "Bad move pile to foundation values.";
    Assert.assertTrue(act.contains(exp));
  }

  /**
   * Tests that a high srcPile number in mpf states illegal move.
   */
  @Test
  public void testMpfHighSrc() {
    StringReader in = input("mpf 10 1 q");
    StringBuilder out = output();
    KlondikeTextualController ktc = ktc(in, out);
    KlondikeModel km = makeKM();
    ktc.playGame(km, km.getDeck(), false, 1, 1);
    String act = out.toString();
    String exp = "Bad move pile to foundation values.";
    Assert.assertTrue(act.contains(exp));
  }

  /**
   * Tests that a low foundPile number in mpf states illegal move.
   */
  @Test
  public void testMpfLowFound() {
    StringReader in = input("mpf 1 -1 q");
    StringBuilder out = output();
    KlondikeTextualController ktc = ktc(in, out);
    KlondikeModel km = makeKM();
    ktc.playGame(km, km.getDeck(), false, 1, 1);
    String act = out.toString();
    String exp = "Bad move pile to foundation values.";
    Assert.assertTrue(act.contains(exp));
  }

  /**
   * Tests that a high foundPile number in mpf states illegal move.
   */
  @Test
  public void testMpfHighFound() {
    StringReader in = input("mpf 1 10 q");
    StringBuilder out = output();
    KlondikeTextualController ktc = ktc(in, out);
    KlondikeModel km = makeKM();
    ktc.playGame(km, km.getDeck(), false, 1, 1);
    String act = out.toString();
    String exp = "Bad move pile to foundation values.";
    Assert.assertTrue(act.contains(exp));
  }

  /**
   * Tests that an illegal mpf move states that the move isn't allowed.
   */
  @Test
  public void testMpfIllegalMove() {
    StringReader in = input("mpf 2 1 q");
    StringBuilder out = output();
    KlondikeTextualController ktc = ktc(in, out);
    KlondikeModel km = makeKM();
    List<Card> cs = makeDeck(
            Arrays.asList(
                    "A♡", "A♢", "K♣", "A♠",
                    "2♡", "2♢", "2♣", "2♠",
                    "3♡", "3♢", "3♣", "3♠",
                    "4♡", "4♢", "4♣", "4♠",
                    "5♡", "5♢", "5♣", "5♠",
                    "6♡", "6♢", "6♣", "6♠",
                    "7♡", "7♢", "7♣", "7♠",
                    "8♡", "8♢", "8♣", "8♠",
                    "9♡", "9♢", "9♣", "9♠",
                    "10♡", "10♢", "10♣", "10♠",
                    "J♡", "J♢", "J♣", "J♠",
                    "Q♡", "Q♢", "Q♣", "Q♠",
                    "K♡", "K♢", "A♣", "K♠"));
    ktc.playGame(km, cs, false, 2, 1);
    String act = out.toString();
    String exp = "Move not allowed.";
    Assert.assertTrue(act.contains(exp));
  }

  /**
   * Tests that you can quit mid mdf in found val.
   */
  @Test
  public void testMdfQuitFound() {
    StringReader in = input("mdf q");
    StringBuilder out = output();
    KlondikeTextualController ktc = ktc(in, out);
    KlondikeModel km = makeKM();
    ktc.playGame(km, km.getDeck(), false, 1, 1);
    String act = out.toString();
    String exp = "Game quit!\nState of game when quit:\n";
    Assert.assertTrue(act.contains(exp));
  }

  /**
   * Tests that a low mdf found pile valid states illegal args.
   */
  @Test
  public void testMdfLowFound() {
    StringReader in = input("mdf -1 q");
    StringBuilder out = output();
    KlondikeTextualController ktc = ktc(in, out);
    KlondikeModel km = makeKM();
    ktc.playGame(km, km.getDeck(), false, 1, 1);
    String act = out.toString();
    String exp = "Bad move draw foundation values";
    Assert.assertTrue(act.contains(exp));
  }

  /**
   * Tests that a high mdf found pile valid states illegal args.
   */
  @Test
  public void testMdfHighFound() {
    StringReader in = input("mdf 10 q");
    StringBuilder out = output();
    KlondikeTextualController ktc = ktc(in, out);
    KlondikeModel km = makeKM();
    ktc.playGame(km, km.getDeck(), false, 1, 1);
    String act = out.toString();
    String exp = "Bad move draw foundation values";
    Assert.assertTrue(act.contains(exp));
  }

  /**
   * Tests that mdf works as expected.
   */
  @Test
  public void testMdfWorks() {
    StringReader in = input("mdf 1 q");
    StringBuilder out = output();
    KlondikeTextualController ktc = ktc(in, out);
    KlondikeModel km = makeKM();
    List<Card> cs = makeDeck(Arrays.asList("A♡", "A♢", "A♣", "A♠"));
    ktc.playGame(km, cs, false, 1, 1);
    String act = out.toString();
    String exp = "Foundation: A♢, <none>, <none>, <none>\n";
    Assert.assertTrue(act.contains(exp));
  }

  /**
   * Tests that mdf works as expected even with random character thrown in.
   */
  @Test
  public void testMdfWorksWithRandomCharacters() {
    StringReader in = input("mdf stereo 1 q");
    StringBuilder out = output();
    KlondikeTextualController ktc = ktc(in, out);
    KlondikeModel km = makeKM();
    List<Card> cs = makeDeck(Arrays.asList("A♡", "A♢", "A♣", "A♠"));
    ktc.playGame(km, cs, false, 1, 1);
    String act = out.toString();
    String exp = "Foundation: A♢, <none>, <none>, <none>\n";
    Assert.assertTrue(act.contains(exp));
  }

  /**
   * Tests that mdf states Move Not Allowed.
   */
  @Test
  public void testMdfMoveNotAllowed() {
    StringReader in = input("mdf 1 q");
    StringBuilder out = output();
    KlondikeTextualController ktc = ktc(in, out);
    KlondikeModel km = makeKM();
    List<Card> cs = makeDeck(Arrays.asList("A♡", "2♢", "A♣", "A♠", "2♡", "A♢", "2♣", "2♠"));
    ktc.playGame(km, cs, false, 1, 1);
    String act = out.toString();
    String exp = "Move not allowed.";
    Assert.assertTrue(act.contains(exp));
  }

  /**
   * Tests that discardDraw states Illegal Move when drawPile is empty.
   */
  @Test
  public void testDDMoveNotAllowed() {
    StringReader in = input("mdf 1 dd q");
    StringBuilder out = output();
    KlondikeTextualController ktc = ktc(in, out);
    KlondikeModel km = makeKM();
    List<Card> cs = makeDeck(Arrays.asList("A♡", "A♢", "A♣", "A♠"));
    ktc.playGame(km, cs, false, 2, 1);
    String act = out.toString();
    String exp1 = "Move not allowed.";
    String exp2 = "Foundation: A♠, <none>, <none>, <none>\n";
    Assert.assertTrue(act.contains(exp1));
    Assert.assertTrue(act.contains(exp2));
  }

  /**
   * Tests that game can be quit with a capital Q.
   */
  @Test
  public void testCapQQuit() {
    StringReader in = input("Q");
    StringBuilder out = output();
    KlondikeTextualController ktc = ktc(in, out);
    KlondikeModel km = makeKM();
    ktc.playGame(km, km.getDeck(), false, 1, 1);
    String act = out.toString();
    String exp = "Game quit!\nState of game when quit:\n";
    Assert.assertTrue(act.contains(exp));
  }

  /**
   * Tests that You Win prints correctly.
   */
  @Test
  public void testYouWin() {
    StringReader in = input("mdf 1 mdf 2 mdf 3 mpf 1 4 q");
    StringBuilder out = output();
    KlondikeTextualController ktc = ktc(in, out);
    KlondikeModel km = makeKM();
    List<Card> cs = makeDeck(Arrays.asList("A♡", "A♢", "A♣", "A♠"));
    ktc.playGame(km, cs, false, 1, 1);
    String act = out.toString();
    String exp = "You win!\n";
    Assert.assertTrue(act.contains(exp));
  }

  /**
   * Tests that a game plays out entirely and correctly even with invalid inputs.
   */
  @Test
  public void testYouWinWithBadInputs() {
    StringReader in = input(
            "a mdf gsn 1 abs mdf plr 2 srt mdf nsw 3 xyz    mpf movith 1 r 4  t q");
    StringBuilder out = output();
    KlondikeTextualController ktc = ktc(in, out);
    KlondikeModel km = makeKM();
    List<Card> cs = makeDeck(Arrays.asList("A♡", "A♢", "A♣", "A♠"));
    ktc.playGame(km, cs, false, 1, 1);
    String act = out.toString();
    String exp = "You win!\n";
    Assert.assertTrue(act.contains(exp));
  }

  /**
   * Tests that Game Over with score prints when there is no valid moves.
   */
  @Test
  public void testGameOver() {
    StringReader in = input("mdf 1 mdf 2 mdf 3 mdf 4 mdf 1 mdf 2 mdf 3 q");
    StringBuilder out = output();
    KlondikeTextualController ktc = ktc(in, out);
    KlondikeModel km = makeKM();
    List<Card> cs = makeDeck(
            Arrays.asList(
                    "K♡", "3♢", "5♡", "6♠",
                    "Q♡", "Q♢", "Q♣", "Q♠",
                    "3♡", "K♢", "3♣", "3♠",
                    "2♡", "4♢", "4♣", "4♠",
                    "5♢", "K♣", "5♣", "5♠",
                    "6♡", "6♢", "6♣", "7♡",
                    "K♠", "7♢", "7♣", "7♠",
                    "8♣", "8♢", "J♡", "8♠",
                    "10♡", "9♢", "9♣", "9♠",
                    "10♣", "10♢", "10♠", "9♡",
                    "8♡", "J♢", "J♣", "J♠",
                    "4♡", "A♢", "A♣", "A♠",
                    "A♡", "2♢", "2♣", "2♠"));
    ktc.playGame(km, cs, false, 9, 1);
    String act = out.toString();
    String exp = "Game over. Score: 7\n";
    Assert.assertTrue(act.contains(exp));
  }

  /**
   * Tests whether the non-top cards in the cascades print faceUp or down.
   */
  @Test
  public abstract void testCascadeFU();
}
