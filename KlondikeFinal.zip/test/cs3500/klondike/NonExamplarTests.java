package cs3500.klondike;

import org.junit.Assert;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import cs3500.klondike.model.hw02.BasicKlondike;
import cs3500.klondike.model.hw02.Card;

/**
 * Tests for BasicKlondike not in the Examplar homework.
 */
public class NonExamplarTests {

  private BasicKlondike bk = new BasicKlondike();
  //Algebraic equation calculating the maximum number of Cascade piles for a given number of cards
  //cast as an int because it always returns a whole number
  private final int MaxNumPiles =
          (int) Math.floor(Math.sqrt((2 * bk.getDeck().size()) + 0.25) - 0.5);

  /**
   * resets the baseKondike for each test.
   */
  private void reset() {
    bk = new BasicKlondike();
  }

  private List<Card> makeDeck(List<String> strings) {
    reset();
    List<Card> ans = new ArrayList<Card>();
    for (String s : strings) {
      for (Card c : bk.getDeck()) {
        if (c.toString().equals(s)) {
          ans.add(c);
        }
      }
    }
    return ans;
  }

  /**
   * Tests whether moving a legal pile of cards into the cascade pile
   * it is currently in throws the proper exception.
   */
  //Chaff11/12
  @Test
  public void testMoveSamePile() {
    reset();
    bk.startGame(bk.getDeck(), false, MaxNumPiles, 1);
    if (MaxNumPiles > 0) {
      Assert.assertThrows("Pile numbers cannot be the same",
              IllegalArgumentException.class, () -> bk.movePile(
                      MaxNumPiles - 1, 1, MaxNumPiles - 1));
    }
  }

  /**
   * Checks whether a makeDeck works properly.
   */
  @Test
  public void testAcesOnly() {
    List<Card> cs = makeDeck(Arrays.asList("A♡", "A♢", "A♣", "A♠"));
    Assert.assertEquals("A♡", cs.get(0).toString());
  }

  /**
   * Checks to make sure that a card is removed from its cascade
   * pile when it moves to a final pile.
   */
  @Test
  public void testOneCardMovementFound() {
    reset();
    List<Card> cs = makeDeck(Arrays.asList("A♡", "A♢", "A♣", "A♠"));
    bk.startGame(cs, false, 1, 1);
    bk.moveToFoundation(0, 0);
    Assert.assertEquals(0, bk.getPileHeight(0));
  }

  /**
   * Checks to make sure Non-King cards can not move into an empty pile.
   */
  @Test
  public void testNonKingMovement() {
    reset();
    List<Card> cs = makeDeck(Arrays.asList("A♡", "A♢", "A♣", "A♠"));
    bk.startGame(cs, false, 2, 1);
    bk.moveToFoundation(0, 0);
    Assert.assertThrows("Can't move a non-king to empty",
            IllegalStateException.class, () -> bk.movePile(1, 1, 0));
  }

  /**
   * Checks to make sure a King can move into an empty cascade pile.
   */
  @Test
  public void testKingMovement() {
    reset();
    List<Card> cs = makeDeck(Arrays.asList(
            "A♡", "A♢", "K♣", "A♠",
            "2♡", "2♢", "2♣", "2♠",
            "3♡", "3♢", "3♣", "3♠",
            "4♡", "4♢", "4♣", "4♠",
            "5♡", "5♢", "5♣", "5♠",
            "6♡", "6♢", "6♣", "6♠",
            "7♡", "7♢", "7♣", "7♠",
            "8♡", "8♢", "8♣", "8♠",
            "9♡", "9♢", "9♣", "9♠",
            "10♡", "10♢", "10♣", "10♠",
            "J♡", "J♢", "J♣", "J♠",
            "Q♡", "Q♢", "Q♣", "Q♠",
            "K♡", "K♢", "A♣", "K♠"));
    bk.startGame(cs, false, 2, 1);
    bk.moveToFoundation(0, 0);
    bk.movePile(1, 1, 0);
    Assert.assertEquals(1, bk.getPileHeight(0));
  }

  /**
   * Checks that the proper exception is thrown when you try to move a card from an empty cascade
   * pile to a foundation pile.
   */
  @Test
  public void testMtMovementFound() {
    reset();
    List<Card> cs = makeDeck(Arrays.asList("A♡", "A♢", "A♣", "A♠"));
    bk.startGame(cs, false, 2, 1);
    bk.moveToFoundation(0, 0);
    Assert.assertThrows("Can't move an empty to foundation.",
            IllegalStateException.class, () -> bk.moveToFoundation(0, 0));
  }

  /**
   * Checks to make sure a card that is one more in value can not move onto a card
   * of a different suit in the foundation piles.
   */
  @Test
  public void testMovemFoundBadSuit() {
    reset();
    List<Card> cs = makeDeck(Arrays.asList("A♡", "A♢", "2♣", "A♠", "2♡", "2♢", "A♣", "2♠"));
    bk.startGame(cs, false, 2, 1);
    bk.moveToFoundation(0, 0);
    Assert.assertThrows("Can't move the wrong suit to foundation",
            IllegalStateException.class, () -> bk.moveToFoundation(1, 0));
  }

  /**
   * Checks to make sure a card that the same suit can not move onto a card
   * not one less in value.
   */
  @Test
  public void testMovemFoundBadVal() {
    reset();
    List<Card> cs = makeDeck(Arrays.asList("A♡", "A♢", "A♡", "A♠", "A♣", "A♢", "A♣", "A♠"));
    bk.startGame(cs, false, 2, 1);
    bk.moveToFoundation(0, 0);
    Assert.assertThrows("Can't move card that is not one greater to foundation",
            IllegalStateException.class, () -> bk.moveToFoundation(1, 0));
  }

  /**
   * Checks to make sure moving the top card of an empty foundation
   * pile to a foundation pile throws the proper exception.
   */
  //Chaff 5
  @Test
  public void testDrawToFound() {
    reset();
    List<Card> cs = makeDeck(Arrays.asList("A♡", "A♢", "A♣", "A♠"));
    bk.startGame(cs, false, 2, 1);
    bk.moveDrawToFoundation(0);
    Assert.assertThrows("Can't move an empty draw pile to foundation",
            IllegalStateException.class, () -> bk.moveDrawToFoundation(0));
  }

  /**
   * Checks to make sure finishing the game properly marks the game as over.
   */
  @Test
  public void testGameOver() {
    reset();
    List<Card> cs = makeDeck(Arrays.asList("A♡", "A♢", "A♣", "A♠"));
    bk.startGame(cs, false, 2, 1);
    boolean beginning = bk.isGameOver();
    bk.moveToFoundation(0, 0);
    bk.moveToFoundation(1, 1);
    bk.moveToFoundation(1, 2);
    bk.moveDrawToFoundation(3);
    boolean end = bk.isGameOver();
    Assert.assertNotEquals(beginning, end);
  }

  /**
   * Checks to assure that a card moves from the Draw pile to cascade pile.
   */
  @Test
  public void testDrawToDest() {
    reset();
    List<Card> cs = makeDeck(Arrays.asList(
            "2♠", "A♢", "A♣", "A♡",
            "2♡", "2♢", "2♣", "A♠"));
    bk.startGame(cs, false, 2, 1);
    bk.moveDraw(0);
    Assert.assertEquals(2, bk.getPileHeight(0));
    Assert.assertEquals(1, bk.getDrawCards().size());
  }

  /**
   * Checks whether removing the top card from a drawpile flips the next card
   * based on the established numDraw cards from the game start.
   */
  @Test
  public void testDrawToFU() {
    reset();
    List<Card> cs = makeDeck(Arrays.asList(
            "2♠", "A♢", "A♣", "A♡",
            "2♡", "2♢", "2♣", "A♠"));
    bk.startGame(cs, false, 2, 1);
    bk.moveDraw(0);
    boolean ans = bk.isCardVisible(0, 0) && bk.isCardVisible(0, 1);
    Assert.assertEquals(true, ans);
  }

  /**
   * Checks to make sure a card stays face up after looping through the drawpile.
   */
  @Test
  public void testCardVis() {
    reset();
    List<Card> cs = makeDeck(Arrays.asList(
            "2♡", "A♢", "A♣", "A♠",
            "A♡", "2♢", "2♣", "2♠"));
    bk.startGame(cs, false, 2, 1);
    bk.discardDraw();
    bk.discardDraw();
    bk.discardDraw();
    bk.discardDraw();
    bk.discardDraw();
    bk.moveDraw(0);
    boolean ans = bk.isCardVisible(0, 0) && bk.isCardVisible(0, 1);
    Assert.assertEquals(true, ans);
  }

  /**
   * Tests to make sure getting a card at a foundation pile that doesn't exist throws
   * the proper exception.
   */
  @Test
  public void testGetCardAtFoundThrow() {
    reset();
    List<Card> cs = makeDeck(Arrays.asList("A♡", "A♢", "A♣", "A♠"));
    bk.startGame(cs, false, 2, 1);
    Assert.assertThrows("Foundation pile does not exist",
            IllegalArgumentException.class, () -> bk.getCardAt(5));
  }

  /**
   * Tests to make sure getCard on an empty cascade returns null.
   */
  @Test
  public void testGetCardAtFoundNull() {
    reset();
    List<Card> cs = makeDeck(Arrays.asList("A♡", "A♢", "A♣", "A♠"));
    bk.startGame(cs, false, 2, 1);
    boolean ans = null == bk.getCardAt(0);
    Assert.assertEquals(true, ans);
  }

  /**
   * Tests to make sure the correct amount of foundation piles are created based
   * on the number of Aces in the deck.
   */
  @Test
  public void testNumFound() {
    reset();
    List<Card> cs = makeDeck(Arrays.asList("A♡", "A♢", "A♣", "A♠"));
    bk.startGame(cs, false, 2, 1);
    Assert.assertEquals(4, bk.getNumFoundations());
  }

  /**
   * Tests to make sure the deck I am creating doesn't return null.
   */
  @Test
  public void testDeckNotNull() {
    BasicKlondike bk = new BasicKlondike();
    boolean ans = bk.getDeck() == null;
    Assert.assertEquals(false, ans);
  }

  /**
   * Checks to make sure there are no null Cards in the deck.
   */
  @Test
  public void testNoNullCards() {
    BasicKlondike bk = new BasicKlondike();
    boolean ans = bk.getDeck().stream().anyMatch(c -> c == null);
    Assert.assertEquals(false, ans);
  }

  /**
   * Checks to make sure none of the cards in the deck's toString returns null.
   */
  @Test
  public void testNoNullToString() {
    BasicKlondike bk = new BasicKlondike();
    boolean ans = bk.getDeck().stream().anyMatch(c -> c.toString() == null);
    Assert.assertFalse(ans);
  }

  /**
   * Tests to make sure the correct exception is thrown when you try to move a pile onto itself.
   */
  //Chaff11/12
  @Test
  public void testMoveSamePile2() {
    BasicKlondike bk = new BasicKlondike();
    bk.startGame(bk.getDeck(), false, 2, 1);
    Assert.assertThrows("Pile numbers cannot be the same",
            IllegalArgumentException.class, () -> bk.movePile(1, 1, 1));

  }

  /**
   * Tests to make sure movePile throws all necessary IllegalArgumentExceptions.
   */
  @Test
  public void testMovePileIAE() {
    BasicKlondike bk = new BasicKlondike();
    bk.startGame(bk.getDeck(), false, 2, 1);
    Assert.assertThrows("Destination Pile Number Must Be Non-Negative",
            IllegalArgumentException.class, () -> bk.movePile(0, 0, -1));
    Assert.assertThrows("Source Pile Number Must Be Non-Negative",
            IllegalArgumentException.class, () -> bk.movePile(-1, 1, 1));
    Assert.assertThrows("Number of Cards Must Be Non-Negative",
            IllegalArgumentException.class, () -> bk.movePile(1, -1, 0));
    Assert.assertThrows("Pile numbers cannot be the same",
            IllegalArgumentException.class, () -> bk.movePile(1, 1, 1));
    Assert.assertThrows("Source pile cannot be greater than the number of piles",
            IllegalArgumentException.class, () -> bk.movePile(13, 1, 1));
    Assert.assertThrows("Destination pile cannot be greater than the number of piles",
            IllegalArgumentException.class, () -> bk.movePile(1, 1, 13));
    Assert.assertThrows(
            "Number of Cards Cannot Be greater than the number of " +
                    "cards in the source pile",
            IllegalArgumentException.class, () -> bk.movePile(
                    0, bk.getPileHeight(1) + 1, 1));
  }

  /**
   * Tests to make sure movePile throws the proper IllegalStateException.
   */
  @Test
  public void testMovePileISE() {
    BasicKlondike bk = new BasicKlondike();
    Assert.assertThrows("Game Must Be Started Before Movement",
            IllegalStateException.class, () -> bk.movePile(1, 1, 1));
  }

  /**
   * Tests to make sure that cards that have been moved have been
   * properly removed from their original source piles.
   */
  @Test
  public void testMovePileCorrectNumCards() {
    BasicKlondike bk = new BasicKlondike();
    bk.startGame(bk.getDeck(), false, 1, 4);
    int ans = bk.getPileHeight(0);
    Assert.assertEquals(1, ans);
  }

  /**
   * Tests to make sure all BasicKlondike methods throw exception if the game has not
   * been started yet.
   */
  @Test
  public void testAnyGameNotStart() {
    BasicKlondike bk = new BasicKlondike();
    Assert.assertThrows("Game must be started",
            IllegalStateException.class, () -> bk.movePile(0, 1, 1));
    Assert.assertThrows("Game must be started",
            IllegalStateException.class, () -> bk.moveDraw(0));
    Assert.assertThrows("Game must be started",
            IllegalStateException.class, () -> bk.moveToFoundation(0, 0));
    Assert.assertThrows("Game must be started",
            IllegalStateException.class, () -> bk.moveDrawToFoundation(0));
    Assert.assertThrows("Game must be started",
            IllegalStateException.class, () -> bk.discardDraw());
    Assert.assertThrows("Game must be started",
            IllegalStateException.class, () -> bk.getNumPiles());
    Assert.assertThrows("Game must be started",
            IllegalStateException.class, () -> bk.getNumRows());
    Assert.assertThrows("Game must be started",
            IllegalStateException.class, () -> bk.getPileHeight(0));
    Assert.assertThrows("Game must be started",
            IllegalStateException.class, () -> bk.getNumRows());
    Assert.assertThrows("Game must be started",
            IllegalStateException.class, () -> bk.getCardAt(0, 1));
    Assert.assertThrows("Game must be started",
            IllegalStateException.class, () -> bk.getCardAt(0));
    Assert.assertThrows("Game must be started",
            IllegalStateException.class, () -> bk.getNumFoundations());
    Assert.assertThrows("Game must be started",
            IllegalStateException.class, () -> bk.getNumDraw());
    Assert.assertThrows("Game must be started",
            IllegalStateException.class, () -> bk.getDrawCards());
    Assert.assertThrows("Game must be started",
            IllegalStateException.class, () -> bk.isGameOver());
    Assert.assertThrows("Game must be started",
            IllegalStateException.class, () -> bk.getScore());
  }

  /**
   * Tests to make sure all starting piles are the correct height.
   */
  @Test
  public void testStartingPileHeights() {
    reset();
    bk.startGame(bk.getDeck(), false, MaxNumPiles, 1);
    int i = MaxNumPiles - 1;
    boolean ans = true;
    while (i >= 0) {
      if (bk.getPileHeight(i) == i + 1) {
        i--;
      } else {
        i = -1;
        ans = false;
      }
    }
    Assert.assertEquals(true, ans);
  }

  /**
   * Checks through every card in the deck and makes sure that only the
   * bottom cards are face up at the start of the game.
   */
  @Test
  public void testStartingIsCardVis() {
    reset();
    bk.startGame(bk.getDeck(), false, MaxNumPiles, 1);
    int i = MaxNumPiles - 1;
    int c = 0;
    boolean ans = true;
    while (i >= 0 && ans) {
      if (bk.isCardVisible(i, c) == (i == c)) {
        c++;
        if (c == bk.getPileHeight(i)) {
          c = 0;
          i--;
        }
      } else {
        ans = false;
      }
    }
    Assert.assertEquals(true, ans);
  }

  /**
   * Tests to make sure cards deal faceUp that should.
   */
  @Test
  public void testFaceUp() {
    List<Card> cs = makeDeck(Arrays.asList("A♡", "A♢", "A♣", "A♠"));
    bk.startGame(cs, false, 1, 1);
    Assert.assertEquals(true, bk.isCardVisible(0, 0));
  }

  /**
   * Tests to make sure an IAE is thrown if you request too many piles for the number of
   * Cards in start game.
   */
  @Test
  public void testTooManyPiles() {
    List<Card> cs = makeDeck(Arrays.asList("A♡", "A♢", "A♣", "A♠"));
    Assert.assertThrows("Too many piles for this many cards",
            IllegalArgumentException.class, () -> bk.startGame(cs, false, 3, 1));
  }

  /**
   * Tests that my get deck behaves properly.
   */
  @Test
  public void testLength() {
    Assert.assertEquals(52, bk.getDeck().size());
    Assert.assertEquals(9, MaxNumPiles);
  }

  /**
   * Tests that a few different games play correctly.
   */
  @Test
  public void testStartGame() {
    reset();
    List<Card> cs0 = makeDeck(Arrays.asList(
            "A♡", "A♢", "A♣", "A♠"));
    List<Card> cs1 = makeDeck(Arrays.asList(
            "A♡", "A♢", "A♣", "A♠",
            "A♡", "A♢", "A♣", "A♠"));
    List<Card> cs2 = makeDeck(Arrays.asList(
            "A♡", "A♢", "A♣", "A♠",
            "2♡", "2♢", "2♣", "2♠"));
    List<Card> cs3 = makeDeck(Arrays.asList(
            "A♡", "A♢", "A♣", "A♠",
            "2♡", "2♢", "2♣", "2♠",
            "A♡", "A♢", "A♣", "A♠"));
    bk.startGame(cs0, false, 1, 1);
    bk.moveDrawToFoundation(0);
    bk.moveDrawToFoundation(1);
    bk.moveDrawToFoundation(2);
    bk.moveToFoundation(0, 3);
    boolean gO0 = bk.isGameOver();
    Assert.assertTrue(gO0);

    reset();
    bk.startGame(cs1, false, 3, 2);
    bk.moveDrawToFoundation(0);
    bk.moveDrawToFoundation(1);
    bk.moveToFoundation(0, 2);
    bk.moveToFoundation(1, 3);
    bk.moveToFoundation(1, 4);
    bk.moveToFoundation(2, 5);
    bk.moveToFoundation(2, 6);
    bk.moveToFoundation(2, 7);
    boolean gO1 = bk.isGameOver();
    Assert.assertTrue(gO1);

    reset();
    bk.startGame(cs2, false, 1, 1);
    bk.moveToFoundation(0, 0);
    bk.moveDrawToFoundation(1);
    bk.moveDrawToFoundation(2);
    bk.moveDrawToFoundation(3);
    bk.moveDrawToFoundation(0);
    bk.moveDrawToFoundation(1);
    bk.moveDrawToFoundation(2);
    bk.moveDrawToFoundation(3);
    boolean gO2 = bk.isGameOver();
    Assert.assertTrue(gO2);

    reset();
    bk.startGame(cs3, false, 3, 1);
    bk.moveToFoundation(0, 0);
    bk.moveToFoundation(1, 1);
    bk.moveToFoundation(1, 2);
    bk.moveToFoundation(2, 2);
    bk.moveToFoundation(2, 0);
    bk.moveToFoundation(2, 3);
    bk.moveDrawToFoundation(3);
    bk.moveDrawToFoundation(1);
    bk.moveDrawToFoundation(4);
    bk.moveDrawToFoundation(5);
    bk.moveDrawToFoundation(6);
    bk.moveDrawToFoundation(7);
    boolean gO3 = bk.isGameOver();
    Assert.assertTrue(gO3);

    reset();
    List<Card> loc = new ArrayList<>();
    Assert.assertThrows("List cannot be empty",
            IllegalArgumentException.class, () -> bk.startGame(
                    loc, false, 1, 1));
  }

  /**
   * An illegal deck with an equal number of each card values.
   */
  @Test
  public void testIllegalDeck() {
    reset();
    List<Card> cs = makeDeck(Arrays.asList(
            "A♡", "A♢", "A♣", "A♠",
            "3♡", "3♢", "3♣", "3♠"));
    Assert.assertThrows("Bad deck",
            IllegalArgumentException.class, () -> bk.startGame(
                    cs, false, 1, 1));
  }

  /**
   * Tests to make sure the highest value card in the deck doesn't have more than the number
   * of foundation piles in the game.
   */
  @Test
  public void testIllegalsInMyDeck() {
    reset();
    List<Card> cs = makeDeck(Arrays.asList(
            "A♡", "A♢", "A♣", "A♠",
            "2♡", "2♢", "2♣", "2♠",
            "2♡", "2♢", "2♣", "2♠"));
    Assert.assertThrows("Bad deck",
            IllegalArgumentException.class, () -> bk.startGame(
                    cs, false, 1, 1));
  }

  /**
   * Test to assure that moving multiple cards to an empty cascade pile works correctly.
   */
  @Test
  public void testKingPile() {
    reset();
    List<Card> cs = makeDeck(Arrays.asList(
            "A♡", "A♢", "A♣", "A♠",
            "2♡", "2♢", "2♣", "2♠",
            "3♡", "K♢", "3♣", "3♠",
            "4♡", "4♢", "4♣", "4♠",
            "5♡", "Q♣", "5♣", "5♠",
            "6♡", "6♢", "6♣", "6♠",
            "7♡", "7♢", "7♣", "7♠",
            "8♡", "8♢", "8♣", "8♠",
            "9♡", "9♢", "9♣", "9♠",
            "10♡", "10♢", "10♣", "10♠",
            "J♡", "J♢", "J♣", "J♠",
            "Q♡", "Q♢", "5♢", "Q♠",
            "K♡", "3♢", "K♣", "K♠"));
    bk.startGame(cs, false, 9 , 1);
    bk.movePile(2, 1, 1);
    bk.moveToFoundation(0, 0);
    bk.movePile(1, 2, 0);
    Assert.assertEquals(2, bk.getPileHeight(0));
    Assert.assertEquals("K♢", bk.getCardAt(0, 0).toString());
    Assert.assertEquals("Q♣", bk.getCardAt(0, 1).toString());
  }

  @Test
  public void test() {
    reset();
    List<Card> cs = makeDeck(Arrays.asList(
            "A♢", "A♠",
            "2♢", "2♠",
            "3♢", "3♠"));
    bk.startGame(cs, true, 2, 1);
    Assert.assertEquals(6, cs.size());
  }
}
