package cs3500.klondike;

import org.junit.Assert;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import cs3500.klondike.model.hw02.BasicKlondike;
import cs3500.klondike.model.hw02.Card;
import cs3500.klondike.model.hw04.LimitedDrawKlondike;
import cs3500.klondike.model.hw04.WhiteheadKlondike;

/**
 * Tests for the extended models that do not count for Examplar.
 */
public class NonExamplarEMTests {

  private BasicKlondike bk = new BasicKlondike();
  private WhiteheadKlondike wk = new WhiteheadKlondike();

  /**
   * resets the baseKlondike for each test.
   */
  private void resetBK() {
    bk = new BasicKlondike();
  }

  /**
   * resets the whiteKlondike for each test.
   */
  private void resetWK() {
    wk = new WhiteheadKlondike();
  }


  private List<Card> makeDeck(List<String> strings) {
    resetBK();
    List<Card> ans = new ArrayList<Card>();
    for (String s : strings) {
      for (Card c : bk.getDeck()) {
        if (c.toString().equals(s)) {
          ans.add(c);
        }
      }
    }
    return ans;
  }

  @Test
  public void testDiscardLDK() {
    LimitedDrawKlondike ldk = new LimitedDrawKlondike(0);
    List<Card> cs = makeDeck(Arrays.asList("A♡", "A♢", "A♣", "A♠"));
    ldk.startGame(cs, false, 2, 1);
    ldk.discardDraw();
    Assert.assertEquals(0, ldk.getDrawCards().size());
  }

  @Test
  public void testDiscardSizeLDK() {
    LimitedDrawKlondike ldk = new LimitedDrawKlondike(2);
    List<Card> cs = makeDeck(Arrays.asList("A♡", "A♢", "A♣", "A♠"));
    ldk.startGame(cs, false, 2, 1);
    Assert.assertEquals(1, ldk.getDrawCards().size());
    ldk.discardDraw();
    Assert.assertEquals(1, ldk.getDrawCards().size());
    ldk.discardDraw();
    Assert.assertEquals(1, ldk.getDrawCards().size());
    ldk.discardDraw();
    Assert.assertEquals(0, ldk.getDrawCards().size());
  }

  @Test
  public void testCardsDealtFUWK() {
    resetWK();
    List<Card> cs = makeDeck(Arrays.asList("A♡", "A♢", "A♣", "A♠"));
    wk.startGame(cs, false, 2, 1);
    Assert.assertTrue(wk.isCardVisible(1, 0));
  }

  @Test
  public void testDiffColorMoveDrawThrowsWK() {
    resetWK();
    List<Card> cs = makeDeck(Arrays.asList(
            "2♡", "A♢", "A♣", "A♠",
            "A♡", "2♢", "2♣", "2♠"));
    wk.startGame(cs, false, 2, 1);
    Assert.assertThrows("Piles must be same color",
            IllegalStateException.class, () -> wk.moveDraw(0));
  }

  @Test
  public void testSameColorMoveDrawAllowsWK() {
    resetWK();
    List<Card> cs = makeDeck(Arrays.asList(
            "2♢", "A♢", "A♣", "A♡",
            "A♠", "2♡", "2♣", "2♠"));
    wk.startGame(cs, false, 2, 1);
    wk.moveDraw(0);
    Assert.assertEquals(2, wk.getPileHeight(0));
  }

  @Test
  public void testMoveAnyCardToMtWK() {
    resetWK();
    List<Card> cs = makeDeck(Arrays.asList("A♡", "A♢", "A♣", "A♠"));
    wk.startGame(cs, false, 2, 1);
    wk.moveToFoundation(0, 0);
    wk.moveDraw(0);
    Assert.assertEquals(1, wk.getPileHeight(0));
  }

  @Test
  public void testDiffColorMovePileThrowsWK() {
    resetWK();
    List<Card> cs = makeDeck(Arrays.asList(
            "2♡", "A♢", "A♣", "A♠",
            "A♡", "2♢", "2♣", "2♠"));
    wk.startGame(cs, false, 2, 1);
    Assert.assertThrows("Piles must be same color",
            IllegalStateException.class, () -> wk.movePile(1, 1, 0));
  }

  @Test
  public void testSameColorMovePileAllowsWK() {
    resetWK();
    List<Card> cs = makeDeck(Arrays.asList(
            "2♢", "A♣", "A♢", "A♡",
            "A♠", "2♡", "2♣", "2♠"));
    wk.startGame(cs, false, 2, 1);
    wk.movePile(1, 1, 0);
    Assert.assertEquals(2, wk.getPileHeight(0));
  }

  @Test
  public void testMoveMultColorsInPile() {
    resetWK();
    List<Card> cs = makeDeck(Arrays.asList(
            "A♢", "A♣", "2♢", "A♡",
            "A♠", "2♡", "2♣", "2♠"));
    wk.startGame(cs, false, 2, 1);
    wk.moveDraw(1);
    Assert.assertEquals(3, wk.getPileHeight(1));
  }

  @Test
  public void testWK() {
    resetWK();
    List<Card> cs = makeDeck(Arrays.asList(
            "A♡", "A♢", "2♣", "A♠",
            "2♡", "2♢", "A♣", "2♠"));
    wk.startGame(cs, false, 2, 1);
    wk.moveToFoundation(0, 0);
    wk.moveDraw(1);
    Assert.assertThrows("All moving cards must be same suit, not just color",
            IllegalStateException.class, () -> wk.movePile(1, 2, 0));
  }

  @Test
  public void testArray() {
    int[] zz = {1, 2, 3, 4};
    zz[0] = 3;
    Assert.assertEquals(zz, new int[]{3, 2, 3, 4});
  }
}
