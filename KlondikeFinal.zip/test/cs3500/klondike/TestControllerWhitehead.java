package cs3500.klondike;

import org.junit.Assert;

import java.io.StringReader;
import java.util.Arrays;
import java.util.List;

import cs3500.klondike.controller.KlondikeTextualController;
import cs3500.klondike.model.hw02.Card;
import cs3500.klondike.model.hw02.KlondikeModel;
import cs3500.klondike.model.hw04.KlondikeCreator;

/**
 * Used for testing that the controller interacts properly with the Whitehead Model.
 */
public class TestControllerWhitehead extends TestController {

  /**
   * Tests whether the non-top cards in the cascades print faceUp or down.
   */
  @Override
  public void testCascadeFU() {
    StringReader in = input("q");
    StringBuilder out = output();
    KlondikeTextualController ktc = ktc(in, out);
    KlondikeModel km = makeKM();
    List<Card> cs = makeDeck(Arrays.asList("A♡", "A♢", "A♣", "A♠"));
    ktc.playGame(km, cs, false, 2, 1);
    String act = out.toString();
    String exp = " A♡ A♢\n    A♣\n";
    Assert.assertTrue(act.contains(exp));
  }

  @Override
  protected KlondikeModel makeKM() {
    return KlondikeCreator.create(KlondikeCreator.GameType.WHITEHEAD);
  }
}
