package cs3500.klondike.model.hw02;

/**
 * The traditional game of klondike.
 * Does not add anything from the abstract because it
 * is the base version.
 */
public final class BasicKlondike extends TraditionalKlondikeModel {

  public BasicKlondike() {
    setStartValues();
  }
}
