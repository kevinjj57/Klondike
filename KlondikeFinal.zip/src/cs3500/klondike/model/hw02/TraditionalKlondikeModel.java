package cs3500.klondike.model.hw02;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Stack;

/**
 * The standard model of klondike.
 */
public abstract class TraditionalKlondikeModel implements cs3500.klondike.model.hw02.KlondikeModel {

  protected List<ArrayList<VisibleCard>> concade;
  protected List<MyCard> drawPile;
  private List<Stack<MyCard>> finalPile;
  private int numDraw;
  private boolean gameStarted;


  /**
   * The base values of all fields before the game begins.
   */
  protected void setStartValues() {
    this.concade = new ArrayList<>();
    this.drawPile = new ArrayList<>();
    this.finalPile = new ArrayList<>();
    this.numDraw = 0;
    this.gameStarted = false;
  }

  /**
   * Shuffles a given deck of cards.
   *
   * @return a deck of cards with the same values in a different order.
   */
  private List<Card> shuffler(List<Card> deck) {
    List<Card> fnl = new ArrayList<Card>();
    int i = deck.size();
    while (i > 0) {
      fnl.add(deck.remove(new Random().nextInt(i)));
      i--;
    }
    return fnl;
  }

  private void shuffler2(List<Card> deck) {
    for (int cardNum = deck.size(); cardNum > 0; cardNum--) {
      deck.add(deck.remove(new Random().nextInt(cardNum)));
    }
  }

  /**
   * Helper method to get the value of the given card.
   *
   * @return the value of the given card.
   * @throws NumberFormatException if the first value is not one of the traditional A-K values.
   */
  protected int getVal(Card c) {
    String x = c.toString().substring(0, c.toString().length() - 1);
    if (x.equals("A")) {
      return 1;
    } else if (x.equals("J")) {
      return 11;
    } else if (x.equals("Q")) {
      return 12;
    } else if (x.equals("K")) {
      return 13;
    } else {
      return Integer.parseInt(x);
    }
  }


  private boolean checkIllegalRuns(List<Card> loc) {
    int numSpades = loc.size();
    int numClubs = loc.size();
    int numHearts = loc.size();
    int numDiamonds = loc.size();
    for (int i = 1; i <= 13; i++) {
      int numSpadesSF = 0;
      int numClubsSF = 0;
      int numHeartsSF = 0;
      int numDiamondsSF = 0;
      for (Card c : loc) {
        if (getVal(c) == i) {
          String suit = c.toString().substring(
                  c.toString().length() - 1);
          switch (suit) {
            case "♠":
              numSpadesSF++;
              break;
            case "♣":
              numClubsSF++;
              break;
            case "♡":
              numHeartsSF++;
              break;
            case "♢":
              numDiamondsSF++;
              break;
            default:
              throw new IllegalArgumentException("Bad Card toString");
          }
        }
      }
      if (numSpadesSF > numSpades
              || numClubsSF > numClubs
              || numHeartsSF > numHearts
              || numDiamondsSF > numDiamonds) {
        return true;
      }
      numSpades = numSpadesSF;
      numClubs = numClubsSF;
      numHearts = numHeartsSF;
      numDiamonds = numDiamondsSF;
    }
    return false;
  }

  /**
   * Checks to see if the given deck is Illegal.
   * In order to be a legal deck, there must be an equal number of cards of each value in each suit
   *
   * @return if the given deck is Illegal.
   */
  private boolean checkIllegalDeck(List<Card> loc) {
    return checkIllegalRuns(loc) || checkIllegalRunSizes(loc);
  }

  private boolean checkIllegalRunSizes(List<Card> loc) {
    int numAces = 0;
    for (Card c : loc) {
      if (getVal(c) == 1) {
        numAces++;
      }
    }

    for (int cardVal = 1; cardVal <= 13; cardVal++) {
      int cardsWithThisVal = 0;
      for (Card c : loc) {
        if (getVal(c) == cardVal) {
          cardsWithThisVal++;
        }
      }
      if (cardsWithThisVal != numAces && cardsWithThisVal != 0) {
        return true;
      }
    }
    return false;
  }

  /**
   * Checks to see if there is not enough Cards in the deck to fill the requested number of piles.
   *
   * @param numOfCards the number of cards in the deck.
   * @param numOfPiles the number of cascade piles wishing to be dealt with that deck.
   * @return if the deal would be illegal.
   */
  private boolean checkNotEnoughCards(int numOfCards, int numOfPiles) {
    return numOfCards < (Math.pow(numOfPiles, 2) + numOfPiles) / 2;
  }

  /**
   * States if the given card is red.
   *
   * @param c the Card you wish to find the color of.
   * @return whether the Card is red.
   */
  protected boolean isRed(Card c) {
    return c.toString().substring(c.toString().length() - 1).equals("♡")
            || c.toString().substring(c.toString().length() - 1).equals("♢");
  }

  /**
   * Checks whether the Card you wish to move is one less than and the opposite
   * color of the card you wish to move it on to. Orr the Card you wish to move is
   * a King and the destination pile is empty.
   *
   * @param moving   the top Card of the pile you wish to move.
   * @param destPile the destination pile in which you wish to add the Card(s) to.
   * @return whether the move is legal.
   */
  protected boolean legalMoveCardToCon(MyCard moving, int destPile) {
    return (kingToMtPile(moving, destPile)
            || ((getPileHeight(destPile) > 0
            && moving.val.value == this.concade.get(destPile)
            .get(getPileHeight(destPile) - 1).card.val.value - 1
            && !isRed(moving) == isRed(getCardAt(destPile, getPileHeight(destPile) - 1)))));
  }

  private boolean kingToMtPile(MyCard moving, int destPile) {
    return moving.val.value == 13 && getPileHeight(destPile) == 0;
  }

  /**
   * Checks if it is legal to move the given Card into the given foundation pile.
   *
   * @param moving    the Card you want to move to a foundation pile.
   * @param foundPile the foundation pile you wish to move the card to.
   * @return whether the move is legal.
   */
  private boolean legalCardToFound(MyCard moving, int foundPile) {
    return legalAceToInactiveFound(moving, foundPile) || legalCardToActiveFound(moving, foundPile);
  }

  private boolean legalCardToActiveFound(MyCard moving, int foundPile) {
    return (this.finalPile.get(foundPile).size() > 0)
            && (this.finalPile.get(foundPile).size() == moving.val.value - 1
            && this.finalPile.get(foundPile).peek().suit.shape.equals(moving.suit.shape));
  }

  private boolean legalAceToInactiveFound(MyCard moving, int foundPile) {
    return (this.finalPile.get(foundPile).size() == 0) && moving.val.value == 1;
  }

  /**
   * Private method to help use loops to build cards.
   *
   * @param i the 1-4 inclusive number associating to each suit:
   *          1, clubs
   *          2, spades
   *          3, hearts
   *          4, diamonds
   * @return the enum for the suit.
   */
  private MyCard.Suit intToSuit(int i) {
    switch (i) {
      case 1:
        return MyCard.Suit.CLUBS;
      case 2:
        return MyCard.Suit.SPADES;
      case 3:
        return MyCard.Suit.HEARTS;
      case 4:
        return MyCard.Suit.DIAMONDS;
      default:
        throw new IllegalArgumentException("Number must be 1-4 inclusive");
    }
  }

  /**
   * Private method to help use loops to build cards.
   *
   * @param i the 1-13 inclusive number associating to each card value:
   * @return the enum for the value.
   */

  private MyCard.CardVal intToCardVal(int i) {
    switch (i) {
      case 1:
        return MyCard.CardVal.ACE;
      case 2:
        return MyCard.CardVal.DEUCE;
      case 3:
        return MyCard.CardVal.THREE;
      case 4:
        return MyCard.CardVal.FOUR;
      case 5:
        return MyCard.CardVal.FIVE;
      case 6:
        return MyCard.CardVal.SIX;
      case 7:
        return MyCard.CardVal.SEVEN;
      case 8:
        return MyCard.CardVal.EIGHT;
      case 9:
        return MyCard.CardVal.NINE;
      case 10:
        return MyCard.CardVal.TEN;
      case 11:
        return MyCard.CardVal.JACK;
      case 12:
        return MyCard.CardVal.QUEEN;
      case 13:
        return MyCard.CardVal.KING;
      default:
        throw new IllegalArgumentException("Bad card must be 1-13 inclusive");
    }
  }

  private boolean illegalCasPileNums(int pileNum) {
    return pileNum >= this.getNumPiles() || pileNum < 0;
  }

  private boolean illegalFoundPileNums(int pileNum) {
    return pileNum >= this.getNumFoundations() || pileNum < 0;
  }

  /**
   * A proper unshuffled deck for BasicKlondike.
   * Ace through King, for clubs, then spades, then hearts, then diamonds.
   *
   * @return an unshuffled deck.
   */
  public List<Card> getDeck() {
    int val = 1;
    int suit = 1;
    List<Card> deck = new ArrayList<>();
    while (deck.size() <= 51) {
      deck.add(new MyCard(intToCardVal(val), intToSuit(suit)));
      if (val == 13) {
        val = 1;
        suit++;
      } else {
        val++;
      }
    }
    return deck;
  }


  /**
   * <p>Deal a new game of Klondike.
   * The cards to be used and their order are specified by the the given deck,
   * unless the {@code shuffle} parameter indicates the order should be ignored.</p>
   *
   * <p>This method first verifies that the deck is valid. It deals cards in rows
   * (left-to-right, top-to-bottom) into the characteristic cascade shape
   * with the specified number of rows, followed by (at most) the specified number of
   * draw cards. When {@code shuffle} is {@code false}, the {@code deck} must be used in
   * order and the 0th card in {@code deck} is used as the first card dealt.
   * There will be as many foundation piles as there are Aces in the deck.</p>
   *
   * <p>A valid deck must consist cards that can be grouped into equal-length,
   * consecutive runs of cards (each one starting at an Ace, and each of a single
   * suit).</p>
   *
   * <p>This method should have no side effects other than configuring this model
   * instance, and should work for any valid arguments.</p>
   *
   * @param deck     the deck to be dealt
   * @param shuffle  if {@code false}, use the order as given by {@code deck},
   *                 otherwise use a randomly shuffled order
   * @param numPiles number of piles to be dealt
   * @param numDraw  maximum number of draw cards available at a time
   * @throws IllegalStateException    if the game has already started
   * @throws IllegalArgumentException if the deck is null or invalid,
   *                                  a full cascade cannot be dealt with the given sizes,
   *                                  or another input is invalid
   */
  @Override
  public void startGame(List<Card> deck, boolean shuffle, int numPiles, int numDraw) {
    if (badStartGameInputs(deck, numPiles, numDraw)) {
      throw new IllegalArgumentException("Invalid startGame input");
    }
    if (gameStarted) {
      throw new IllegalStateException("Game already started");
    }
    this.gameStarted = true;
    this.numDraw = numDraw;

    makeEngoughFoundationPiles(deck);
    makeEnoughCascadePiles(numPiles);

    if (shuffle) {
      shuffler2(deck);
    }

    dealCards(numPiles, deck);
    flipCards(numPiles);
  }

  protected void flipCards(int numPiles) {
    for (int pile = 0; pile < numPiles; pile++) {
      if (this.concade.get(pile).size() != 0) {
        this.concade.get(pile).get(this.concade.get(pile).size() - 1).flipCard();
      }
    }
  }

  private void dealCards(int numPiles, List<Card> deck) {
    //The maximum number of cards to be delt is equal to
    //the number of piles squared plus the number of piles,
    //all divided by two
    List<MyCard> deal = new ArrayList<>();
    //Creates a deep copy of the deck.
    for (Card c : deck) {
      deal.add(new MyCard(c));
    }

    for (int heightSF = 0; heightSF < numPiles; heightSF++) {
      for (int pileNum = 0; pileNum < numPiles; pileNum++) {
        if (deal.size() != 0) {
          if (this.concade.get(pileNum).size() <= pileNum) {
            this.concade.get(pileNum).add(new VisibleCard(deal.remove(0)));
          }
        }
      }
    }
    this.drawPile.addAll(deal);
  }

  private void makeEngoughFoundationPiles(List<Card> deck) {
    for (Card c : deck) {
      if (c.toString().substring(0, 1).equals("A")) {
        this.finalPile.add(new Stack<>());
      }
    }
  }

  private void makeEnoughCascadePiles(int numPiles) {
    for (int i = numPiles; i > 0; i--) {
      this.concade.add(new ArrayList<VisibleCard>());
    }
  }

  private boolean badStartGameInputs(List<Card> deck, int numPiles, int numDraw) {
    return deck == null || deck.stream().anyMatch(c -> c == null)
            || checkIllegalDeck(deck)
            || checkNotEnoughCards(deck.size(), numPiles)
            || numDraw < 1 || numPiles < 1;
  }

  private int getNumFUinPile(int pile) {
    if (pile > getNumPiles() || pile < 0) {
      throw new IllegalArgumentException("Bad pile number");
    }
    int ans = 0;
    for (VisibleCard c : this.concade.get(pile)) {
      if (c.isFU()) {
        ans++;
      }
    }
    return ans;
  }


  /**
   * Moves the requested number of cards from the source pile to the destination pile,
   * if allowable by the rules of the game.
   *
   * @param srcPile  the 0-based index (from the left) of the pile to be moved
   * @param numCards how many cards to be moved from that pile
   * @param destPile the 0-based index (from the left) of the destination pile for the
   *                 moved cards
   * @throws IllegalStateException    if the game hasn't been started yet
   * @throws IllegalArgumentException if either pile number is invalid, if the pile
   *                                  numbers are the same, or there are not enough cards
   *                                  to move from
   *                                  the srcPile to the destPile (i.e. the move is not physically
   *                                  possible)
   * @throws IllegalStateException    if the move is not allowable (i.e. the move is not
   *                                  logically possible)
   */
  public void movePile(int srcPile, int numCards, int destPile) {
    if (!(gameStarted) || isGameOver()) {
      throw new IllegalStateException("Game hasn't started or is over");
    }
    if (illegalMPArgs(srcPile, numCards, destPile)) {
      throw new IllegalArgumentException("Illegal movePile args");
    }
    MyCard movingCard = this.concade.get(srcPile).get(getPileHeight(srcPile) - numCards).card;
    if (illegalMPmove(srcPile, numCards, destPile, movingCard)) {
      throw new IllegalStateException("Move is not allowed");
    }
    int beginPileHeight = getPileHeight(srcPile);
    for (int i = numCards; i > 0; i--) {
      this.concade.get(destPile).add(
              this.concade.get(srcPile).remove(beginPileHeight - numCards));
    }
    if (this.concade.get(srcPile).size() > 0) {
      if (!this.concade.get(srcPile).get(this.concade.get(srcPile).size() - 1).isFU()) {
        this.concade.get(srcPile).get(this.concade.get(srcPile).size() - 1).flipCard();
      }
    }
  }

  private boolean illegalMPmove(int srcPile, int numCards, int destPile, MyCard movingCard) {
    return numCards > getPileHeight(srcPile)
            || !isCardVisible(srcPile, getPileHeight(srcPile) - numCards)
            || !legalMoveCardToCon(movingCard, destPile)
            || !legalMovers(srcPile, numCards);
  }

  private boolean illegalMPArgs(int srcPile, int numCards, int destPile) {
    return illegalCasPileNums(srcPile)
            || illegalCasPileNums(destPile)
            || srcPile == destPile
            || numCards > getNumFUinPile(srcPile)
            || numCards < 1;
  }

  protected boolean legalMovers(int srcPile, int numCards) {
    return true;
  }

  /**
   * Moves the topmost draw-card to the destination pile.  If no draw cards remain,
   * reveal the next available draw cards
   *
   * @param destPile the 0-based index (from the left) of the destination pile for the
   *                 card
   * @throws IllegalStateException    if the game hasn't been started yet
   * @throws IllegalArgumentException if destination pile number is invalid
   * @throws IllegalStateException    if there are no draw cards, or if the move is not
   *                                  allowable
   */
  public void moveDraw(int destPile) throws IllegalStateException {
    if (!(gameStarted) || isGameOver()) {
      throw new IllegalStateException("Game hasn't started or is over");
    }
    if (illegalMDArgs(destPile)) {
      throw new IllegalArgumentException("Bad destination pile");
    }
    if (illegalMDmove(destPile)) {
      throw new IllegalStateException("That move is not legal");
    }
    VisibleCard fc = new VisibleCard(this.drawPile.remove(0));
    this.concade.get(destPile).add(fc);
    fc.flipCard();
  }

  private boolean illegalMDArgs(int destPile) {
    return illegalCasPileNums(destPile);
  }

  private boolean illegalMDmove(int destPile) {
    return this.drawPile.size() <= 0 ||
            !legalMoveCardToCon(this.drawPile.get(0), destPile);
  }

  /**
   * Moves the top card of the given pile to the requested foundation pile.
   *
   * @param srcPile        the 0-based index (from the left) of the pile to move a card
   * @param foundationPile the 0-based index (from the left) of the foundation pile to
   *                       place the card
   * @throws IllegalStateException    if the game hasn't been started yet
   * @throws IllegalArgumentException if either pile number is invalid
   * @throws IllegalStateException    if the source pile is empty or if the move is not
   *                                  allowable
   */
  public void moveToFoundation(int srcPile, int foundationPile) {
    if (!(gameStarted) || isGameOver()) {
      throw new IllegalStateException("Game hasn't started or is over");
    }
    if (illegalMTFArgs(srcPile, foundationPile)) {
      throw new IllegalArgumentException("Invalid Pile Number1");
    }
    if (illegalMTFmove(srcPile, foundationPile)) {
      throw new IllegalStateException("Not valid move");
    }
    this.finalPile.get(foundationPile).
            add(this.concade.get(srcPile).remove(getPileHeight(srcPile) - 1).card);
    if (this.concade.get(srcPile).size() > 0
            && !isCardVisible(srcPile, getPileHeight(srcPile) - 1)) {
      this.concade.get(srcPile).get(getPileHeight(srcPile) - 1).flipCard();
    }
  }

  private boolean illegalMTFmove(int srcPile, int foundationPile) {
    return this.concade.get(srcPile).size() == 0
            || !legalCardToFound(this.concade.get(srcPile)
            .get(getPileHeight(srcPile) - 1).card, foundationPile);
  }

  private boolean illegalMTFArgs(int srcPile, int foundationPile) {
    return illegalCasPileNums(srcPile) || illegalFoundPileNums(foundationPile);
  }

  /**
   * Moves the topmost draw-card directly to a foundation pile.
   *
   * @param foundationPile the 0-based index (from the left) of the foundation pile to
   *                       place the card
   * @throws IllegalStateException    if the game hasn't been started yet
   * @throws IllegalArgumentException if the foundation pile number is invalid
   * @throws IllegalStateException    if there are no draw cards or if the move is not
   *                                  allowable
   */
  public void moveDrawToFoundation(int foundationPile) {
    if (!(gameStarted) || isGameOver()) {
      throw new IllegalStateException("Game hasn't started or is over");
    }
    if (illegalMDTFArgs(foundationPile)) {
      throw new IllegalArgumentException("Invalid Pile Number2");
    }
    if (illegalMDTFmove(foundationPile)) {
      throw new IllegalStateException("Move not allowed");
    }
    this.finalPile.get(foundationPile).add(this.drawPile.remove(0));
  }

  private boolean illegalMDTFmove(int foundationPile) {
    return this.drawPile.size() == 0
            || !legalCardToFound(this.drawPile.get(0), foundationPile);
  }

  private boolean illegalMDTFArgs(int foundationPile) {
    return illegalFoundPileNums(foundationPile);
  }

  /**
   * Discards the topmost draw-card.
   *
   * @throws IllegalStateException if the game hasn't been started yet
   * @throws IllegalStateException if move is not allowable
   */
  public void discardDraw() throws IllegalStateException {
    if (!(gameStarted) || isGameOver()) {
      throw new IllegalStateException("Game hasn't started or is over");
    }
    if (illegalDDmove()) {
      throw new IllegalStateException("Draw Empty");
    } else {
      discardCard();
    }
  }

  private boolean illegalDDmove() {
    return this.drawPile.size() == 0;
  }

  protected void discardCard() {
    this.drawPile.add(this.drawPile.remove(0));
  }


  /**
   * Returns the number of rows currently in the game.
   *
   * @return the height of the current table of cards
   * @throws IllegalStateException if the game hasn't been started yet
   */
  public int getNumRows() {
    if (!(gameStarted)) {
      throw new IllegalStateException("Game hasn't started");
    } else {
      int i = 0;
      for (ArrayList<VisibleCard> alc : this.concade) {
        if (alc.size() > i) {
          i = alc.size();
        }
      }
      return i;
    }
  }

  /**
   * Returns the number of piles for this game.
   *
   * @return the number of piles
   * @throws IllegalStateException if the game hasn't been started yet
   */
  public int getNumPiles() {
    if (!(gameStarted)) {
      throw new IllegalStateException("Game hasn't started");
    } else {
      return this.concade.size();
    }
  }

  /**
   * Returns the maximum number of visible cards in the draw pile.
   *
   * @return the number of visible cards in the draw pile
   * @throws IllegalStateException if the game hasn't been started yet
   */
  public int getNumDraw() {
    if (!(gameStarted)) {
      throw new IllegalStateException("Game hasn't started");
    }
    return this.numDraw;
  }

  /**
   * Helper for game over that checks if any of the bottom Cards
   * in the destination piles can move to the final piles.
   *
   * @return whether there is no possible move from destination to final.
   */
  private boolean noMoveToFound() {
    for (int pileNum = 0; pileNum < this.getNumPiles(); pileNum++) {
      for (int foundPileNum = this.finalPile.size() - 1; foundPileNum >= 0; foundPileNum--) {
        if (getPileHeight(pileNum) != 0) {
          if (legalCardToFound(this.concade.get(pileNum)
                  .get(getPileHeight(pileNum) - 1).card, foundPileNum)) {
            return false;
          }
        }
      }
    }
    return true;
  }

  /**
   * Helper for gameOver to check and make sure there are no more possible lateral movements.
   *
   * @return whether there is no more possible moves across these cascade piles
   */
  private boolean noMoveAcross() {
    for (int pileNum = 0; pileNum < getNumPiles(); pileNum++) {
      for (int cardNum = this.concade.get(pileNum).size() - 1; cardNum >= 0; cardNum--) {
        for (int pileNum2 = 0; pileNum2 < getNumPiles(); pileNum2++) {
          if (this.concade.get(pileNum).get(cardNum).isFU()) {
            if (pileNum2 != pileNum) {
              if (legalMoveCardToCon(this.concade.get(pileNum).get(cardNum).card, pileNum2)
                      && legalMovers(pileNum, this.concade.get(pileNum).size() - cardNum)) {
                return false;
              }
            }
          }
        }
      }
    }
    return true;
  }

  /**
   * Checks to see if all cascade piles are empty.
   *
   * @return whether they are all empty.
   */
  private boolean allConcsMt() {
    for (ArrayList<VisibleCard> arc : this.concade) {
      if (arc.size() > 0) {
        return false;
      }
    }
    return true;
  }

  /**
   * Signal if the game is over or not.  A game is over if there are no more
   * possible moves to be made, or draw cards to be used (or discarded).
   *
   * @return true if game is over, false otherwise
   * @throws IllegalStateException if the game hasn't been started yet
   */
  public boolean isGameOver() {
    if (!(gameStarted)) {
      throw new IllegalStateException("Game hasn't started");
    } else {
      return this.drawPile.size() == 0 && (allConcsMt() || (noMoveToFound() && noMoveAcross()));
    }
  }

  /**
   * Return the current score, which is the sum of the values of the cards
   * in the foundation piles.
   *
   * @return the score
   * @throws IllegalStateException if the game hasn't been started yet
   */
  public int getScore() throws IllegalStateException {
    if (!(gameStarted)) {
      throw new IllegalStateException("Game hasn't started");
    } else {
      int i = 0;
      for (Stack<MyCard> st : this.finalPile) {
        if (st.size() > 0) {
          i += st.peek().val.value;
        }
      }
      return i;
    }
  }


  /**
   * Returns the number of cards in the specified pile.
   *
   * @param pileNum the 0-based index (from the left) of the pile
   * @return the number of cards in the specified pile
   * @throws IllegalStateException    if the game hasn't been started yet
   * @throws IllegalArgumentException if pile number is invalid
   */
  public int getPileHeight(int pileNum) throws IllegalStateException {
    if (!(gameStarted)) {
      throw new IllegalStateException("Game hasn't started");
    }
    if (pileNum >= getNumPiles() || pileNum < 0) {
      throw new IllegalArgumentException("Invalid Pile Number3");
    }
    return this.concade.get(pileNum).size();
  }

  /**
   * Returns whether the card at the specified coordinates is face-up or not.
   *
   * @param pileNum column of the desired card (0-indexed from the left)
   * @param card    row of the desired card (0-indexed from the top)
   * @return whether the card at the given position is face-up or not
   * @throws IllegalStateException    if the game hasn't been started yet
   * @throws IllegalArgumentException if the coordinates are invalid
   */
  public boolean isCardVisible(int pileNum, int card) throws IllegalStateException {
    if (!(gameStarted)) {
      throw new IllegalStateException("Game hasn't started");
    }
    if (illegalCardVisArgs(pileNum, card)) {
      throw new IllegalArgumentException("Invalid Coordinates");
    }
    return this.concade.get(pileNum).get(card).isFU();
  }

  private boolean illegalCardVisArgs(int pileNum, int card) {
    return pileNum >= this.concade.size() || pileNum < 0
            || card >= this.getPileHeight(pileNum)
            || card < 0;
  }


  private boolean illegalPileArgsGCA(int pileNum) {
    return pileNum >= this.concade.size() || pileNum < 0;
  }

  private boolean illegalCardArgsGCA(int pileNum, int card) {
    return card >= this.concade.get(pileNum).size()
            || card < 0 || !isCardVisible(pileNum, card);
  }

  /**
   * Returns the card at the specified coordinates, if it is visible.
   *
   * @param pileNum column of the desired card (0-indexed from the left)
   * @param card    row of the desired card (0-indexed from the top)
   * @return the card at the given position, or <code>null</code> if no card is there
   * @throws IllegalStateException    if the game hasn't been started yet
   * @throws IllegalArgumentException if the coordinates are invalid
   */
  public Card getCardAt(int pileNum, int card) throws IllegalStateException {
    if (!(gameStarted)) {
      throw new IllegalStateException("Game hasn't started");
    }
    if (illegalPileArgsGCA(pileNum)) {
      throw new IllegalArgumentException("Bad pile num");
    }
    if (this.concade.get(pileNum).size() == 0 && card == 0) {
      return null;
    }
    if (illegalCardArgsGCA(pileNum, card)) {
      throw new IllegalArgumentException("Invalid Coordinates");
    }
    return this.concade.get(pileNum).get(card).card;
  }



  /**
   * Returns the card at the top of the specified foundation pile.
   * @param foundationPile 0-based index (from the left) of the foundation pile
   * @return the card at the given position, or <code>null</code> if no card is there
   * @throws IllegalStateException if the game hasn't been started yet
   * @throws IllegalArgumentException if the foundation pile number is invalid
   */
  public Card getCardAt(int foundationPile) throws IllegalStateException {
    if (!(gameStarted)) {
      throw new IllegalStateException("Game hasn't started");
    }
    if (foundationPile >= this.finalPile.size() || foundationPile < 0) {
      throw new IllegalArgumentException("Invalid Pile Number4");
    }
    if (this.finalPile.get(foundationPile).size() == 0) {
      return null;
    } else {
      return this.finalPile.get(foundationPile).peek();
    }
  }

  /**
   * Returns the currently available draw cards.
   * There should be at most {@link KlondikeModel#getNumDraw} cards (the number
   * specified when the game started) -- there may be fewer, if cards have been removed.
   * NOTE: Users of this method should not modify the resulting list.
   * @return the ordered list of available draw cards (i.e. first element of this list
   *         is the first one to be drawn)
   * @throws IllegalStateException if the game hasn't been started yet
   */
  public List<Card> getDrawCards() throws IllegalStateException {
    List<Card> lc;
    if (!(gameStarted)) {
      throw new IllegalStateException("Game hasn't started");
    } else {
      lc = new ArrayList<>();
      for (int drawCard = 0; drawCard < drawPile.size() && drawCard < getNumDraw(); drawCard++) {
        lc.add(drawPile.get(drawCard));
      }
    }
    return lc;
  }

  /**
   * Return the number of foundation piles in this game.
   * @return the number of foundation piles
   * @throws IllegalStateException if the game hasn't been started yet
   */
  public int getNumFoundations() throws IllegalStateException {
    if (!(gameStarted)) {
      throw new IllegalStateException("Game hasn't started");
    } else {
      return this.finalPile.size();
    }
  }
}