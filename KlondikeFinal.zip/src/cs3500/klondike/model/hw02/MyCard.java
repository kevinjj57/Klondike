package cs3500.klondike.model.hw02;

import java.util.Objects;

/**
 * My version of the card interface which uses enums to insure proper Crads.
 */
public final class MyCard implements Card {

  /**
   * An enumeration of the only allowable Card "values" for this game.
   * Includes their number equivilance and their String.
   */
  public enum CardVal {
    ACE(1, "A"),
    DEUCE(2, "2"),
    THREE(3, "3"),
    FOUR(4, "4"),
    FIVE(5, "5"),
    SIX(6, "6"),
    SEVEN(7, "7"),
    EIGHT(8, "8"),
    NINE(9, "9"),
    TEN(10, "10"),
    JACK(11, "J"),
    QUEEN(12, "Q"),
    KING(13, "K");

    /**
     * The integer value associated with this card.
     */
    public final int value;

    /**
     * The suit symbol of this card.
     */
    public final String sym;

    CardVal(int value, String sym) {
      this.value = value;
      this.sym = sym;
    }
  }

  /**
   * An enumeration of all the suits allowed for this game.
   * Their shape String representation is included.
   */
  public enum Suit {

    CLUBS("♣"),
    SPADES("♠"),
    HEARTS("♡"),
    DIAMONDS("♢");

    final String shape;

    Suit(String shape) {
      this.shape = shape;
    }
  }

  //check ordinal
  public final CardVal val;
  public final Suit suit;

  /**
   * Constructor for the playing card that sets the card face-down.
   * @param val one of the Ace through King enums.
   * @param suit one of the four enum suits.
   */
  public MyCard(CardVal val, Suit suit) {
    this.val = val;
    this.suit = Objects.requireNonNull(suit);
  }

  /**
   * An easy constructor that takes a generic card and makes an MyCard with the
   * equivalent suit and value.
   */
  public MyCard(Card card) {
    String cardString = card.toString();
    String val = cardString.substring(0, cardString.length() - 1);
    String suit = cardString.substring(cardString.length() - 1);
    this.val = getVal(val);
    this.suit = getSuit(suit);
  }

  protected CardVal getVal(String s) {
    switch (s) {
      case "A":
        return CardVal.ACE;
      case "2":
        return CardVal.DEUCE;
      case "3":
        return CardVal.THREE;
      case "4":
        return CardVal.FOUR;
      case "5":
        return CardVal.FIVE;
      case "6":
        return CardVal.SIX;
      case "7":
        return CardVal.SEVEN;
      case "8":
        return CardVal.EIGHT;
      case "9":
        return CardVal.NINE;
      case "10":
        return CardVal.TEN;
      case "J":
        return CardVal.JACK;
      case "Q":
        return CardVal.QUEEN;
      case "K":
        return CardVal.KING;
      default:
        throw new IllegalArgumentException("Bad String");
    }
  }

  protected Suit getSuit(String s) {
    switch (s) {
      case "♣":
        return Suit.CLUBS;
      case "♠":
        return Suit.SPADES;
      case "♡":
        return Suit.HEARTS;
      case "♢":
        return Suit.DIAMONDS;
      default:
        throw new IllegalArgumentException("Bad suit");
    }
  }

  /**
   * Renders a card with its value followed by its suit as one of
   * the following symbols (♣, ♠, ♡, ♢).
   * For example, the 3 of Hearts is rendered as {@code "3♡"}.
   * @return the formatted card.
   */
  public String toString() {
    return this.val.sym + this.suit.shape;
  }


  /**
   * Overriding because two Cards are equal if their toString value is the same,
   * not only based on hashcode or class.
   * @param o the object you wish to compare with this myCard.
   * @return whether the two objects are equal.
   */
  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    } else {
      if (o instanceof Card) {
        Card cobj = (Card) o;
        return cobj.toString().equals(this.toString());
      } else {
        return false;
      }
    }
  }

  /**
   * As required when overriding @code{.equals}, determining the hashcode by the card's fields.
   * @return the hashcode associated with this card.
   */
  public int hashCode() {
    return Objects.hash(this.val.sym, this.val.value, this.suit.shape);
  }
}
