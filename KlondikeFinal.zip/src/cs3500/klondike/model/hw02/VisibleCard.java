package cs3500.klondike.model.hw02;

/**
 * A class to keep track of a MyCard and whether it is face up or not.
 * A Card does not inheritly have a faceUp or down trait, so that is being tracked separately.
 */
public final class VisibleCard {

  private boolean fu;
  final public MyCard card;

  public VisibleCard(Card card) {
    this.fu = false;
    this.card = new MyCard(card);
  }


  /**
   * Determines whether this card is face-up.
   *
   * @return whether this card is face-up.
   */
  public boolean isFU() {
    return this.fu;
  }

  /**
   * Flips this card to the opposite side.
   */
  public void flipCard() {
    this.fu = !this.fu;
  }
}
