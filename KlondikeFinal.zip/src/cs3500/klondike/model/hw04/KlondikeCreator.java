package cs3500.klondike.model.hw04;

import cs3500.klondike.model.hw02.BasicKlondike;
import cs3500.klondike.model.hw02.KlondikeModel;

/**
 * A factory class to create one of the KlondikeModels.
 */
public final class KlondikeCreator {

  /**
   * The currently created and implemented KlondikeModel implementations.
   */
  public enum GameType {
    BASIC,
    LIMITED,
    WHITEHEAD;
  }

  /**
   * A builder method that creates the appropriate Klondike Model.
   * (SETS LIMITED REDRAW ATTEMPTS TO 2 AUTOMATICALLY).
   * @param type the enumeration representing the KlondikeModel you wish to make.
   * @return the appropriate KlondikeModel.
   */
  public static KlondikeModel create(GameType type) {
    switch (type) {
      case BASIC:
        return new BasicKlondike();
      case LIMITED:
        return new LimitedDrawKlondike(2);
      case WHITEHEAD:
        return new WhiteheadKlondike();
      default:
        throw new IllegalArgumentException("GameType not yet created.");
    }
  }
}
