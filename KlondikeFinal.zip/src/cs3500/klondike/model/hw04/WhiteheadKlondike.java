package cs3500.klondike.model.hw04;

import java.util.ArrayList;
import cs3500.klondike.model.hw02.Card;
import cs3500.klondike.model.hw02.MyCard;
import cs3500.klondike.model.hw02.TraditionalKlondikeModel;
import cs3500.klondike.model.hw02.VisibleCard;

import static java.util.Map.copyOf;

/**
 * An alternative GameType of BasicKlondike with the following rule changes:
 *   1. All cards are dealt face-up.
 *   2. All cards moving to.in the Cascade Piles must be the same color of the card it is
 *   being places upon.
 *   3. When attempting to move multiple cards, all cards must be the same suit as one another.
 *   4. Any card can be place into an empty cascade pile as long as the move is valid.
 */
public final class WhiteheadKlondike extends TraditionalKlondikeModel {

  public WhiteheadKlondike() {
    setStartValues();
  }

  @Override
  protected void flipCards(int numPiles) {
    for (ArrayList<VisibleCard> arc : this.concade) {
      for (VisibleCard c : arc) {
        c.flipCard();
      }
    }
  }

  private String getSuit(Card c) {
    return c.toString().substring(c.toString().length() - 1);
  }

  @Override
  protected boolean legalMoveCardToCon(MyCard moving, int destPile) {
    ArrayList<VisibleCard> arc = this.concade.get(destPile);
    return arc.size() == 0
            || (isRed(arc.get(arc.size() - 1).card) == isRed(moving)
            && arc.get(arc.size() - 1).card.val.value == moving.val.value + 1);
  }

  @Override
  protected boolean legalMovers(int srcPile, int numCards) {
    if (numCards == 1) {
      return true;
    } else {
      Card startCard = getCardAt(srcPile, getPileHeight(srcPile) - numCards);
      int aboveVal = getVal(startCard);
      String aboveSuit = getSuit(startCard);
      for (int cardsSF = numCards - 1; cardsSF > 0; cardsSF--) {
        Card thisCard = getCardAt(srcPile, getPileHeight(srcPile) - cardsSF);
        if (!getSuit(thisCard).equals(aboveSuit) || getVal(thisCard) + 1 != aboveVal) {
          return false;
        } else {
          aboveVal = getVal(thisCard);
          aboveSuit = getSuit(thisCard);
        }
      }
    }
    return true;
  }
}