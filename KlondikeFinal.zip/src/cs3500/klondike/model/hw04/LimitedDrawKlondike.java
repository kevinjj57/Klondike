package cs3500.klondike.model.hw04;

import cs3500.klondike.model.hw02.TraditionalKlondikeModel;

/**
 * An implementation of KlondikeModel that takes an integer that represents the number of times
 * a player can discard through the entire drawPile before cards are lost forever.
 */
public final class LimitedDrawKlondike extends TraditionalKlondikeModel {

  private int numRedrawsLeft;
  private int numDD;

  /**
   * Constructor for LDK.
   * @param numTimesRedrawAllowed the number of times you wish to see a card after the first
   *                              time it has been discarded. Must be greater than
   *                              or equal to zero.
   *
   */
  public LimitedDrawKlondike(int numTimesRedrawAllowed) {
    if (numTimesRedrawAllowed < 0) {
      throw new IllegalArgumentException("Num redraws can't be less than zero.");
    }
    setStartValues();
    this.numRedrawsLeft = numTimesRedrawAllowed;
    this.numDD = 0;
  }

  @Override
  protected void discardCard() {
    if (this.numDD == this.drawPile.size()) {
      this.numRedrawsLeft--;
      this.numDD = 0;
    }
    if (numRedrawsLeft == 0) {
      this.drawPile.remove(0);
    } else {
      this.drawPile.add(this.drawPile.remove(0));
      this.numDD++;
    }
  }
}
