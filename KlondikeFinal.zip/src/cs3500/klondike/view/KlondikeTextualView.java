package cs3500.klondike.view;

import java.io.IOException;

import cs3500.klondike.model.hw02.Card;
import cs3500.klondike.model.hw02.KlondikeModel;

/**
 * A simple text-based rendering of the Klondike game.
 */
public final class KlondikeTextualView implements TextualView {
  private final KlondikeModel model;
  private final Appendable out;

  public KlondikeTextualView(KlondikeModel model) {
    this.model = model;
    this.out = System.out;
  }

  public KlondikeTextualView(KlondikeModel model, Appendable out) {
    this.model = model;
    this.out = out;
  }

  /**
   * The textview of the current model.
   *
   * @return a string with linebreaks and spaces places properly in order to
   *     allow a clean viewing experience for this Klondike model.
   */
  public String toString() {
    String ans = "Draw: ";
    for (Card c : model.getDrawCards()) {
      ans += c.toString() + ", ";
    }

    if (model.getDrawCards().size() != 0) {
      ans = ans.substring(0, ans.length() - 2);
    }
    ans += "\nFoundation:";
    for (int i = 0; i < model.getNumFoundations(); i++) {
      if (model.getCardAt(i) == null) {
        ans += " <none>,";
      } else {
        ans += " " + model.getCardAt(i).toString() + ",";
      }
    }


    int maxPileHeight = 0;
    for (int z = model.getNumPiles() - 1; z >= 0; z--) {
      if (model.getPileHeight(z) > maxPileHeight) {
        maxPileHeight = model.getPileHeight(z);
      }
    }

    ans = ans.substring(0, ans.length() - 1);

    for (int currentHeight = 0; currentHeight < maxPileHeight; currentHeight++) {
      ans += "\n";
      for (int currentColumn = 0; currentColumn < model.getNumPiles(); currentColumn++) {
        if (currentHeight == 0 && model.getPileHeight(currentColumn) == 0) {
          ans += "  X";
        } else {
          if (model.getPileHeight(currentColumn) > currentHeight) {
            if (model.isCardVisible(currentColumn, currentHeight)) {
              if (model.getCardAt(currentColumn, currentHeight).toString().length() == 3) {
                ans += model.getCardAt(currentColumn, currentHeight).toString();
              } else {
                ans += " " + model.getCardAt(currentColumn, currentHeight).toString();
              }
            } else {
              ans += "  ?";
            }
          } else {
            ans += "   ";
          }

        }
      }
    }
    return ans;
  }

  /**
   * Renders a model in some manner (e.g. as text, or as graphics, etc.).
   *
   * @throws IOException if the rendering fails for some reason
   */
  @Override
  public void render() throws IOException {
    out.append(this.toString());
  }
}
