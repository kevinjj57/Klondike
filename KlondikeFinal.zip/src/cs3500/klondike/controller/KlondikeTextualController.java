package cs3500.klondike.controller;

import java.io.IOException;
import java.util.List;
import java.util.Scanner;

import cs3500.klondike.model.hw02.Card;
import cs3500.klondike.model.hw02.KlondikeModel;
import cs3500.klondike.view.KlondikeTextualView;

/**
 * A version of the klondike controller that deals with text inputs and outputs.
 */
public final class KlondikeTextualController implements KlondikeController {

  private final Readable in;
  private final Appendable out;

  /**
   * Constructor for KlondikeTextualController.
   *
   * @param r a Readable to take inputs.
   * @param a an Appendable to take outputs.
   * @throws null pointer exception if either is Null.
   */
  public KlondikeTextualController(Readable r, Appendable a) {
    this.in = r;
    this.out = a;
  }

  /**
   * The primary method for beginning and playing a game.
   *
   * @param model    The game of solitaire to be played
   * @param deck     The deck of cards to be used
   * @param shuffle  Whether to shuffle the deck or not
   * @param numPiles How many piles should be in the initial deal
   * @param numDraw  How many draw cards should be visible
   * @throws IllegalArgumentException if the model, reader, or appendable is null
   *                                  added input/output to javadoc.
   *                                  That's what examplar tests are suggesting.
   * @throws IllegalStateException    if the game cannot be started,
   *                                  or if the controller cannot interact with the player.
   */
  @Override
  public void playGame(
          KlondikeModel model,
          List<Card> deck,
          boolean shuffle,
          int numPiles,
          int numDraw) {
    if (model == null || this.in == null || this.out == null) {
      throw new IllegalArgumentException("Model/Input/Output can't be Null");
    }
    try {
      model.startGame(deck, shuffle, numPiles, numDraw);
    } catch (IllegalArgumentException e) {
      throw new IllegalStateException("Game cannot be started");
    }
    try {
      getGameMoving(model);
    } catch (IllegalArgumentException e) {
      throw new IllegalArgumentException("Controller cannot interact with the player");
    } catch (IllegalStateException e) {
      throw new IllegalStateException("Controller cannot interact with the player");
    } catch (IOException e) {
      throw new IllegalStateException("Controller unable to be rendered.");
    }
  }

  private void getGameMoving(KlondikeModel model) throws IOException {
    boolean quit = false;
    Scanner sc = new Scanner(this.in);
    KlondikeTextualView ktv = new KlondikeTextualView(model, this.out);
    displayBoard(ktv);
    if (!sc.hasNext()) {
      throw new IllegalStateException("Controller cannot interact with the player");
    }
    while (!quit) {
      if (!model.isGameOver()) {
        if (!sc.hasNext()) {
          throw new IllegalStateException("Bad reader");
        }
        String userMethodCall = sc.next();
        switch (userMethodCall) {
          case "mpp":
            try {
              int src = inPileModPile(intOrQ(sc));
              int numCards = intOrQ(sc);
              int destPile = inPileModPile(intOrQ(sc));
              model.movePile(src, numCards, destPile);
              displayBoard(ktv);
            } catch (IllegalArgumentException e) {
              errorMessage("Bad move pile values.");
              displayBoard(ktv);
            } catch (IllegalStateException e) {
              errorMessage("Move not allowed.");
              displayBoard(ktv);
            } catch (RuntimeException e) {
              quit = true;
            }
            break;
          case "md":
            try {
              int destPile = inPileModPile(intOrQ(sc));
              model.moveDraw(destPile);
              displayBoard(ktv);
            } catch (IllegalArgumentException e) {
              errorMessage("Bad move draw value.");
              displayBoard(ktv);
            } catch (IllegalStateException e) {
              errorMessage("Move not allowed.");
              displayBoard(ktv);
            } catch (RuntimeException e) {
              quit = true;
            }
            break;
          case "mpf":
            try {
              int src = inPileModPile(intOrQ(sc));
              int found = inPileModPile(intOrQ(sc));
              model.moveToFoundation(src, found);
              displayBoard(ktv);
            } catch (IllegalArgumentException e) {
              errorMessage("Bad move pile to foundation values.");
              displayBoard(ktv);
            } catch (IllegalStateException e) {
              errorMessage("Move not allowed.");
              displayBoard(ktv);
            } catch (RuntimeException e) {
              quit = true;
            }
            break;
          case "mdf":
            try {
              int found = inPileModPile(intOrQ(sc));
              model.moveDrawToFoundation(found);
              displayBoard(ktv);
            } catch (IllegalArgumentException e) {
              errorMessage("Bad move draw foundation values");
              displayBoard(ktv);
            } catch (IllegalStateException e) {
              errorMessage("Move not allowed.");
              displayBoard(ktv);
            } catch (RuntimeException e) {
              quit = true;
            }
            break;
          case "dd":
            try {
              model.discardDraw();
              displayBoard(ktv);
            }
            catch (IllegalStateException e) {
              errorMessage("Move not allowed.");
              displayBoard(ktv);
            }
            break;
          case "q":
          case "Q":
            quit = true;
            break;
          default:
            errorMessage("Must call one of the five available methods or end game.");
            displayBoard(ktv);        }
        addNewLine();
      } else {
        gameOverPrintMessage(model);
        break;
      }
    }
    if (quit) {
      writeMessage("Game quit!");
      writeMessage("State of game when quit:");
      displayBoard(ktv);
      writeMessage("Score: " + model.getScore());
    }
  }

  /**
   * Translates the input pile index to the model pile index.
   * (ex. model zero based, input one based)
   *
   * @param pile the inputted pile number.
   * @return the pile number for the model.
   */
  private int inPileModPile(int pile) {
    return pile - 1;
  }

  /**
   * A helper recursive method to get the next integer or end the game.
   *
   * @param in the inputted text from the controller.
   * @return the integer to relay to the model.
   * @throws RuntimeException if a {@code "q"} is inputted. Signals to the model to end the game.
   */
  private int intOrQ(Scanner in) {
    String next = in.next();
    if (next.equalsIgnoreCase("q")) {
      throw new RuntimeException("Game Over");
    } else {
      try {
        return Integer.parseInt(next);
      } catch (Exception e) {
        return intOrQ(in);
      }
    }
  }

  /**
   * Helper method to write a message for the on the screen.
   * Adds a new line on the end of the message.
   *
   * @param s the desired string message wishing to append on screen.
   * @throws IllegalStateException if the String is non-appendable.
   */
  private void writeMessage(String s) {
    try {
      out.append(s);
      addNewLine();
    } catch (IOException e) {
      throw new IllegalStateException(e.getMessage());
    }
  }

  /**
   * Helper method to display an error on the screen.
   *
   * @param s the reason the move is invalid.
   */
  private void errorMessage(String s) {
    writeMessage("Invalid move. Play again. " + s);
  }

  private void gameOverPrintMessage(KlondikeModel m) {
    boolean mtPiles = true;
    for (int i = m.getNumPiles() - 1; i >= 0; i--) {
      if (m.getPileHeight(i) != 0) {
        mtPiles = false;
      }
    }
    boolean mtDraw = m.getDrawCards().size() == 0;
    if (mtPiles && mtDraw) {
      writeMessage("You win!");
    } else {
      writeMessage("Game over. Score: " + m.getScore());
    }
  }

  /**
   * Adds a new line onto the end of the message.
   */
  private void addNewLine() {
    try {
      out.append("\n");
    }
    catch (IOException e) {
      throw new IllegalArgumentException("IOE");
    }
  }

  private void displayBoard(KlondikeTextualView ktv) {
    try {
      ktv.render();
      addNewLine();
    }
    catch (IOException e) {
      throw new IllegalArgumentException("Bad appendable");
    }
  }
}