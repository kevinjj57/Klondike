package cs3500.klondike;

import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.Iterator;

import cs3500.klondike.controller.KlondikeTextualController;
import cs3500.klondike.model.hw02.KlondikeModel;
import cs3500.klondike.model.hw04.KlondikeCreator;
import cs3500.klondike.model.hw04.LimitedDrawKlondike;

/**
 * The interactive way users can interact with the Klondike models.
 */
public final class Klondike {
  /**
   * The method that allows the computer to run this game.
   * @param args the inputs you wish to have.
   *             First String should be the model name,
   *             IF you are playing limited the next argument
   *             should be the number of redraws you wish to allow.
   *             The next two arguments are then the number of piles you wish to have, and the
   *             number of draw cards you wish to see.
   *             If you do not specify numPiles or numDraw, they will be automatically set to
   *             7 & 3 respectively.
   *             You may specify numPiles and not numDraw,
   *             but you may not specify numPiles and not numDraw.
   */
  public static void main(String[] args) {
    Iterator<String> iterStrings = Arrays.stream(args).iterator();
    if (iterStrings.hasNext()) {
      switch (iterStrings.next()) {
        case "basic":
          startBasic(iterStrings);
          break;
        case "limited":
          startLimited(iterStrings);
          break;
        case "whitehead":
          startWhitehead(iterStrings);
          break;
        default:
          throw new IllegalArgumentException("Unknown Model Type");
      }
    } else {
      throw new IllegalArgumentException("Need to enter arguments to start game");
    }
  }

  private static void startLimited(Iterator<String> iterStrings) {
    if (!iterStrings.hasNext()) {
      throw new IllegalArgumentException("Limited must be given an integer as its second argument");
    } else {
      try {
        int ans = Integer.parseInt(iterStrings.next());
        if (ans > 0) {
          KlondikeModel limitedModel = new LimitedDrawKlondike(ans - 1);
          getPileAmtsOrStart(limitedModel, iterStrings);
        } else {
          throw new IllegalArgumentException("Next must be a positive int");
        }
      } catch (RuntimeException e) {
        throw new IllegalArgumentException("Limited needs an int as second argument");
      }
    }
  }

  private static void startBasic(Iterator<String> iterStrings) {
    KlondikeModel km = KlondikeCreator.create(KlondikeCreator.GameType.BASIC);
    getPileAmtsOrStart(km, iterStrings);
  }

  private static void startWhitehead(Iterator<String> iterStrings) {
    KlondikeModel km = KlondikeCreator.create(KlondikeCreator.GameType.WHITEHEAD);
    getPileAmtsOrStart(km, iterStrings);
  }

  private static void klondikeModelQuickStart(KlondikeModel km) {
    Readable readable = new InputStreamReader(System.in);
    KlondikeTextualController ktc = new KlondikeTextualController(readable, System.out);
    ktc.playGame(km, km.getDeck(), true, 7, 3);
  }

  private static void klondikeModelSemiSpecificStart(KlondikeModel km, int numPiles) {
    Readable readable = new InputStreamReader(System.in);
    KlondikeTextualController ktc = new KlondikeTextualController(readable, System.out);
    try {
      ktc.playGame(km, km.getDeck(), true, numPiles, 3);
    }
    catch (IllegalStateException e) {
      throw new IllegalArgumentException("Bad semiSpecific args");
    }
  }

  private static void klondikeModelSpecificStart(KlondikeModel km, int numPiles, int numDraw) {
    Readable readable = new InputStreamReader(System.in);
    KlondikeTextualController ktc = new KlondikeTextualController(readable, System.out);
    try {
      ktc.playGame(km, km.getDeck(), true, numPiles, numDraw);
    } catch (IllegalStateException e) {
      throw new IllegalArgumentException("Bad Specific args");
    }
  }

  private static void getPileAmtsOrStart(KlondikeModel km, Iterator<String> iterator) {
    try {
      int numPiles = Integer.parseInt(iterator.next());
      try {
        specificStart(km, iterator, numPiles);
      }
      catch (RuntimeException e) {
        try {
          semiSpecificStart(km, numPiles);
        } catch (RuntimeException ex) {
          klondikeModelQuickStart(km);
        }
      }
    } catch (RuntimeException exp) {
      try {
        klondikeModelQuickStart(km);
      }
      catch (IllegalStateException ise) {
        System.out.println(ise);
      }
    }
  }

  private static void semiSpecificStart(KlondikeModel km, int numPiles) {
    klondikeModelSemiSpecificStart(km, numPiles);
  }

  private static void specificStart(KlondikeModel km, Iterator<String> iterator, int numPiles) {
    int numDraw = Integer.parseInt(iterator.next());
    klondikeModelSpecificStart(km, numPiles, numDraw);
  }
}